import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from .api.routes import router as api_router
from .data.db import init_db
from .data.seed_data import seed_database
from .data.search_service import get_all_rooms

from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    rooms = get_all_rooms()
    if not rooms or len(rooms) < 5:
        print("Seeding database on initial application startup...")
        seed_database()
    yield

app = FastAPI(
    title="Campus Compass – SITCOE",
    description="AI-Powered 3D Indoor Navigation System for SITCOE grounded in verified campus CAD data.",
    version="2.0.0",
    lifespan=lifespan
)

from fastapi.middleware.gzip import GZipMiddleware

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# GZip compression for ultra-fast asset & CAD geometry delivery
app.add_middleware(GZipMiddleware, minimum_size=1000)

# Include API Router
app.include_router(api_router)

# Static files path
APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, "static")
TEMPLATES_DIR = os.path.join(APP_DIR, "templates")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/")
def serve_index():
    index_file = os.path.join(TEMPLATES_DIR, "index.html")
    return FileResponse(index_file)

@app.get("/logo.png")
def serve_logo():
    return FileResponse(os.path.join(STATIC_DIR, "logo.png"), headers={"Cache-Control": "public, max-age=86400"})

@app.get("/style.css")
def serve_css():
    return FileResponse(os.path.join(STATIC_DIR, "css", "style.css"), headers={"Cache-Control": "public, max-age=3600"})

@app.get("/script.js")
def serve_script():
    return FileResponse(os.path.join(STATIC_DIR, "js", "script.js"), headers={"Cache-Control": "public, max-age=3600"})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("campus_compass.app.main:app", host="0.0.0.0", port=8000, reload=True)
