// ==========================================================================
// Campus Compass AI – Voice & Text Assistant Client
// Web Speech Recognition + Neural Edge-TTS Streaming + Navigation Dispatch
// ==========================================================================

class CampusAssistantClient {
    constructor() {
        this.panel = document.getElementById("aiAssistantPanel");
        this.chatHistory = document.getElementById("aiChatHistory");
        this.textInput = document.getElementById("aiTextInput");
        this.btnSend = document.getElementById("btnSendAIMessage");
        this.btnMic = document.getElementById("btnVoiceInput");
        this.voiceStatusBar = document.getElementById("voiceStatusBar");
        this.langSelect = document.getElementById("aiLanguageSelect");

        this.recognition = null;
        this.isListening = false;
        this.currentAudio = null;

        this.init();
    }

    init() {
        // Speech Recognition Setup
        const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (SpeechRec) {
            this.recognition = new SpeechRec();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;

            this.recognition.onstart = () => {
                this.isListening = true;
                this.updateListeningUI(true);
            };

            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                this.handleUserInput(transcript);
            };

            this.recognition.onerror = (event) => {
                console.warn("Speech recognition error:", event.error);
                this.updateListeningUI(false);
            };

            this.recognition.onend = () => {
                this.isListening = false;
                this.updateListeningUI(false);
            };
        } else {
            console.warn("Web SpeechRecognition is not supported in this browser. Fallback to text input.");
        }

        // Event Listeners
        if (this.btnMic) {
            this.btnMic.addEventListener("click", () => this.toggleVoiceListening());
        }

        if (this.btnSend) {
            this.btnSend.addEventListener("click", () => this.sendTextMessage());
        }

        if (this.textInput) {
            this.textInput.addEventListener("keydown", (e) => {
                if (e.key === "Enter") this.sendTextMessage();
            });
        }
    }

    toggleVoiceListening() {
        if (!this.recognition) {
            alert("Speech recognition is not available in your browser. Please type your message into the assistant.");
            this.openPanel();
            return;
        }

        if (this.isListening) {
            this.recognition.stop();
        } else {
            const lang = this.langSelect ? this.langSelect.value : "en-US";
            this.recognition.lang = lang;
            try {
                this.recognition.start();
                this.openPanel();
            } catch (err) {
                console.error("Recognition start failure:", err);
            }
        }
    }

    updateListeningUI(listening) {
        if (this.btnMic) {
            this.btnMic.classList.toggle("listening", listening);
        }
        if (this.voiceStatusBar) {
            this.voiceStatusBar.style.display = listening ? "flex" : "none";
        }
    }

    openPanel() {
        if (this.panel) this.panel.style.display = "flex";
    }

    closePanel() {
        if (this.panel) this.panel.style.display = "none";
    }

    sendTextMessage() {
        const text = this.textInput.value.trim();
        if (!text) return;
        this.textInput.value = "";
        this.handleUserInput(text);
    }

    appendMessage(text, sender) {
        const msgDiv = document.createElement("div");
        msgDiv.className = `chat-msg ${sender}`;
        msgDiv.innerHTML = `<p>${text}</p>`;
        this.chatHistory.appendChild(msgDiv);
        this.chatHistory.scrollTop = this.chatHistory.scrollHeight;
    }

    async handleUserInput(queryText) {
        this.openPanel();
        this.appendMessage(queryText, "user");

        const lang = this.langSelect ? this.langSelect.value : "en-US";
        const currentLoc = document.getElementById("startPointSelect") ? document.getElementById("startPointSelect").value : "MAIN_GATE";

        try {
            const resp = await fetch("/api/assistant/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    query: queryText,
                    current_location: currentLoc,
                    current_floor: 0,
                    language: lang
                })
            });

            const data = await resp.json();
            this.appendMessage(data.reply_text, "assistant");

            // Speak response
            this.speakText(data.spoken_text, lang);

            // If navigation payload returned, trigger campus navigation
            if (data.navigation && data.navigation.success) {
                if (window.onAssistantNavigationTriggered) {
                    window.onAssistantNavigationTriggered(data.navigation, data.destination_room);
                }
            }
        } catch (err) {
            console.error("Assistant query failure:", err);
            this.appendMessage("Sorry, I encountered an error while processing your request. Please try again.", "assistant");
        }
    }

    speakText(text, lang) {
        // Stop any currently playing audio
        if (this.currentAudio) {
            this.currentAudio.pause();
            this.currentAudio = null;
        }

        // Attempt Neural Edge-TTS endpoint first
        const ttsUrl = `/api/tts?text=${encodeURIComponent(text)}&lang=${lang}`;
        const audio = new Audio(ttsUrl);

        audio.play().then(() => {
            this.currentAudio = audio;
        }).catch(err => {
            // Fallback to browser SpeechSynthesis
            console.warn("Audio element play error, falling back to window.speechSynthesis:", err);
            if ('speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(text);
                utterance.lang = lang;
                window.speechSynthesis.speak(utterance);
            }
        });
    }
}

window.CampusAssistantClient = CampusAssistantClient;
