// ==========================================================================
// Campus Compass – SITCOE Interactive 3D Building Viewer (Three.js)
// Grounded in verified CAD geometry from 02.Main Building Sheet with lift.dwg
// ==========================================================================

class BuildingViewer3D {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;

        this.floorGroups = {}; // { 0: Group, 1: Group, 2: Group }
        this.cadGeometryData = null;
        this.currentFloorView = "1"; // Default to First Floor (CSE)
        this.wallHeight = 2.8; // 2.8m wall height for cut-away architectural view
        this.show3DWalls = true;

        this.routeMesh = null;
        this.startPin = null;
        this.destPin = null;
        this.userMarker = null;
        this.userPulseRing = null;

        // Shared reusable material for dynamic route tube (avoids WebGL shader recompilations)
        this.routeMaterial = new THREE.MeshStandardMaterial({
            color: 0x0284c7,
            emissive: 0x0ea5e9,
            emissiveIntensity: 0.9,
            roughness: 0.15
        });

        // Camera smooth zoom & follow targets
        this.targetCamPos = new THREE.Vector3();
        this.targetLookAt = new THREE.Vector3();
        this.isFocusing = false;
        this.fullPath3D = null;

        this.roomMeshes = [];
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();

        this.init();
    }

    init() {
        const width = this.container.clientWidth || window.innerWidth;
        const height = this.container.clientHeight || window.innerHeight;

        // Scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0xf1f5f9); // Modern architectural light slate
        this.scene.fog = new THREE.FogExp2(0xf1f5f9, 0.003);

        // Camera
        this.camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 1000);
        this.camera.position.set(32.5, -60, 65);
        this.camera.up.set(0, 0, 1); // Z is vertical up in CAD architecture

        // Renderer
        this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        this.renderer.setSize(width, height);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        this.container.appendChild(this.renderer.domElement);

        // OrbitControls
        this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        this.controls.target.set(32.5, 32.5, 5); // Center on courtyard
        this.controls.maxPolarAngle = Math.PI / 2 - 0.05; // Do not go below ground

        // Lighting (Clean daylight architectural lighting)
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.95);
        this.scene.add(ambientLight);

        const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.65);
        dirLight1.position.set(50, -30, 80);
        dirLight1.castShadow = true;
        this.scene.add(dirLight1);

        const dirLight2 = new THREE.DirectionalLight(0x93c5fd, 0.35);
        dirLight2.position.set(-30, 60, 60);
        this.scene.add(dirLight2);

        // Ground reference grid (Subtle light architectural grid)
        const gridHelper = new THREE.GridHelper(120, 24, 0x94a3b8, 0xe2e8f0);
        gridHelper.rotation.x = Math.PI / 2;
        gridHelper.position.set(32.5, 32.5, -0.05);
        this.scene.add(gridHelper);

        // Handle window resizing
        window.addEventListener("resize", () => this.onResize());

        // Setup mouse click raycasting for room selection
        this.renderer.domElement.addEventListener("click", (e) => this.onCanvasClick(e));

        // Start render loop
        this.animate();
    }

    onResize() {
        if (!this.container) return;
        const width = this.container.clientWidth;
        const height = this.container.clientHeight;
        this.camera.aspect = width / height;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(width, height);
    }

    async loadCADGeometry(geomData = null) {
        if (geomData) {
            this.cadGeometryData = geomData;
            this.buildBuildingFloors();
            return;
        }
        try {
            const resp = await fetch("/api/cad/geometry");
            this.cadGeometryData = await resp.json();
            this.buildBuildingFloors();
        } catch (err) {
            console.error("Error loading CAD geometry for 3D viewer:", err);
        }
    }

    buildBuildingFloors() {
        const floorElevations = {
            0: 0.00,
            1: 4.95,
            2: 9.00
        };

        // Create groups for each floor
        for (const [fid, elev] of Object.entries(floorElevations)) {
            const floorGroup = new THREE.Group();
            floorGroup.position.set(0, 0, elev);
            floorGroup.name = `Floor_${fid}`;

            // Build floor slab with courtyard hole
            const slab = this.createFloorSlab();
            floorGroup.add(slab);

            // Build walls from CAD polylines
            if (this.cadGeometryData && this.cadGeometryData.layers) {
                const wallGroup = this.createCADWalls(this.cadGeometryData.layers);
                floorGroup.add(wallGroup);
            }

            // Build Staircases and Lift shafts
            this.buildVerticalCores(floorGroup, parseInt(fid));

            this.scene.add(floorGroup);
            this.floorGroups[fid] = floorGroup;
        }

        // Apply initial floor isolation
        this.setFloorView(this.currentFloorView);
    }

    createFloorSlab() {
        // Outer quadrangle: 65.14m x 65.44m
        // Courtyard hole (O.T.S.): 33.18m x 21.58m centered at (32.5, 30.0)
        const slabShape = new THREE.Shape();
        slabShape.moveTo(0, 0);
        slabShape.lineTo(65.14, 0);
        slabShape.lineTo(65.14, 65.44);
        slabShape.lineTo(0, 65.44);
        slabShape.lineTo(0, 0);

        // Courtyard hole
        const holePath = new THREE.Path();
        const holeX = 16.0;
        const holeY = 18.0;
        const holeW = 33.18;
        const holeH = 21.58;
        holePath.moveTo(holeX, holeY);
        holePath.lineTo(holeX + holeW, holeY);
        holePath.lineTo(holeX + holeW, holeY + holeH);
        holePath.lineTo(holeX, holeY + holeH);
        holePath.lineTo(holeX, holeY);
        slabShape.holes.push(holePath);

        const extrudeSettings = {
            steps: 1,
            depth: 0.25,
            bevelEnabled: false
        };

        const geom = new THREE.ExtrudeGeometry(slabShape, extrudeSettings);
        geom.translate(0, 0, -0.25); // Top of slab at z=0

        const mat = new THREE.MeshStandardMaterial({
            color: 0xffffff, // Crisp white architectural floor slab
            roughness: 0.9,
            metalness: 0.05
        });

        const slabMesh = new THREE.Mesh(geom, mat);
        slabMesh.receiveShadow = true;
        return slabMesh;
    }

    createCADWalls(layers) {
        const wallGroup = new THREE.Group();
        const wallLayers = ["plan", "walls", "STONE WALL", "COLUMN"];

        const linePositions = [];
        for (const layerName of wallLayers) {
            const polylines = layers[layerName] || [];
            for (const pts of polylines) {
                if (pts.length < 2) continue;
                for (let i = 0; i < pts.length - 1; i++) {
                    linePositions.push(pts[i][0], pts[i][1], 0.08);
                    linePositions.push(pts[i+1][0], pts[i+1][1], 0.08);
                }
            }
        }

        if (linePositions.length > 0) {
            const lineGeom = new THREE.BufferGeometry();
            lineGeom.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
            const lineMat = new THREE.LineBasicMaterial({
                color: 0x1d4ed8, // Vibrant royal blue architectural line work
                transparent: true,
                opacity: 0.85
            });
            const linesMesh = new THREE.LineSegments(lineGeom, lineMat);
            wallGroup.add(linesMesh);
        }

        // Clean low-profile 3D architectural corridor and boundary walls
        if (this.show3DWalls) {
            const wallMat = new THREE.MeshStandardMaterial({
                color: 0xdbeafe, // Soft translucent architectural light walls
                roughness: 0.6,
                metalness: 0.05,
                transparent: true,
                opacity: 0.75
            });

            // Outer perimeter walls (h=1.8m for architectural view)
            const h = 1.8;
            const wOuterS = new THREE.Mesh(new THREE.BoxGeometry(65.14, 0.4, h), wallMat);
            wOuterS.position.set(32.57, 0.2, h / 2);
            wallGroup.add(wOuterS);

            const wOuterN = new THREE.Mesh(new THREE.BoxGeometry(65.14, 0.4, h), wallMat);
            wOuterN.position.set(32.57, 65.24, h / 2);
            wallGroup.add(wOuterN);

            const wOuterW = new THREE.Mesh(new THREE.BoxGeometry(0.4, 65.44, h), wallMat);
            wOuterW.position.set(0.2, 32.72, h / 2);
            wallGroup.add(wOuterW);

            const wOuterE = new THREE.Mesh(new THREE.BoxGeometry(0.4, 65.44, h), wallMat);
            wOuterE.position.set(64.94, 32.72, h / 2);
            wallGroup.add(wOuterE);

            // Courtyard interior parapet walls (h=0.9m)
            const hp = 0.9;
            const parapetMat = new THREE.MeshStandardMaterial({
                color: 0x94a3b8, // Light architectural parapet
                roughness: 0.4
            });

            const cpS = new THREE.Mesh(new THREE.BoxGeometry(33.18, 0.3, hp), parapetMat);
            cpS.position.set(32.59, 18.0, hp / 2);
            wallGroup.add(cpS);

            const cpN = new THREE.Mesh(new THREE.BoxGeometry(33.18, 0.3, hp), parapetMat);
            cpN.position.set(32.59, 39.58, hp / 2);
            wallGroup.add(cpN);

            const cpW = new THREE.Mesh(new THREE.BoxGeometry(0.3, 21.58, hp), parapetMat);
            cpW.position.set(16.0, 28.79, hp / 2);
            wallGroup.add(cpW);

            const cpE = new THREE.Mesh(new THREE.BoxGeometry(0.3, 21.58, hp), parapetMat);
            cpE.position.set(49.18, 28.79, hp / 2);
            wallGroup.add(cpE);
        }

        return wallGroup;
    }

    createWallSegment(p1, p2, thickness, height, mat) {
        const dx = p2[0] - p1[0];
        const dy = p2[1] - p1[1];
        const len = Math.hypot(dx, dy);
        const angle = Math.atan2(dy, dx);

        const geom = new THREE.BoxGeometry(len, thickness, height);
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2, height / 2);
        mesh.rotation.z = angle;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        return mesh;
    }

    buildVerticalCores(floorGroup, floorId) {
        // Staircase S1 (South-West Core) at (20.5, 7.0)
        const s1Geom = new THREE.BoxGeometry(8.47, 4.5, 2.5);
        const s1Mat = new THREE.MeshStandardMaterial({
            color: 0xf59e0b, // Amber yellow for stairs
            transparent: true,
            opacity: 0.75,
            wireframe: false
        });
        const s1Mesh = new THREE.Mesh(s1Geom, s1Mat);
        s1Mesh.position.set(20.5, 7.0, 1.25);
        floorGroup.add(s1Mesh);

        // Staircase S2 (North-East Core) at (48.5, 57.0)
        const s2Geom = new THREE.BoxGeometry(5.2, 4.5, 2.5);
        const s2Mesh = new THREE.Mesh(s2Geom, s1Mat);
        s2Mesh.position.set(48.5, 57.0, 1.25);
        floorGroup.add(s2Mesh);

        // Lift Shaft L1 at (39.9, 17.1)
        const liftGeom = new THREE.BoxGeometry(1.8, 1.8, 3.5);
        const liftMat = new THREE.MeshStandardMaterial({
            color: 0x8b5cf6, // Tech purple for lift
            transparent: true,
            opacity: 0.8
        });
        const liftMesh = new THREE.Mesh(liftGeom, liftMat);
        liftMesh.position.set(39.9, 17.1, 1.75);
        floorGroup.add(liftMesh);
    }

    populateRoomMarkers(rooms) {
        // Clear previous room markers
        this.roomMeshes.forEach(m => this.scene.remove(m));
        this.roomMeshes = [];

        rooms.forEach(r => {
            const fg = this.floorGroups[r.floor_id];
            if (!fg) return;

            const w = r.width || 6.0;
            const l = r.length || 6.0;

            const roomGeom = new THREE.BoxGeometry(w * 0.9, l * 0.9, 0.4);
            const colorHex = parseInt((r.color || "#3b82f6").replace("#", "0x"));
            const roomMat = new THREE.MeshStandardMaterial({
                color: colorHex,
                transparent: true,
                opacity: 0.45,
                roughness: 0.3
            });

            const mesh = new THREE.Mesh(roomGeom, roomMat);
            mesh.position.set(r.x, r.y, 0.2);
            mesh.userData = r;
            fg.add(mesh);
            this.roomMeshes.push(mesh);
        });
    }

    setFloorView(floorView) {
        this.currentFloorView = floorView;

        if (floorView === "ALL") {
            // Show all floors stacked
            for (const [fid, group] of Object.entries(this.floorGroups)) {
                group.visible = true;
                group.position.z = { 0: 0.0, 1: 5.5, 2: 11.0 }[fid]; // Slightly expanded for vertical clarity
            }
            this.camera.position.set(32.5, -80, 80);
            this.controls.target.set(32.5, 32.5, 6);
        } else {
            // Isolate single floor
            const targetFloor = parseInt(floorView);
            for (const [fid, group] of Object.entries(this.floorGroups)) {
                const isTarget = parseInt(fid) === targetFloor;
                group.visible = isTarget;
                group.position.z = 0.0; // Place isolated floor on ground plane
            }
            this.camera.position.set(32.5, -50, 55);
            this.controls.target.set(32.5, 32.5, 0);
        }
        this.controls.update();
    }

    renderRoute(path3D, floorsInvolved) {
        // Clear existing route
        if (this.routeMesh) {
            this.scene.remove(this.routeMesh);
            this.routeMesh = null;
        }
        if (this.startPin) {
            this.scene.remove(this.startPin);
            this.startPin = null;
        }
        if (this.destPin) {
            this.scene.remove(this.destPin);
            this.destPin = null;
        }

        if (!path3D || path3D.length < 2) return;
        this.fullPath3D = path3D;

        // Auto switch to ALL floors if multi-floor route, else isolate floor
        if (floorsInvolved && floorsInvolved.length > 1) {
            this.setFloorView("ALL");
            document.querySelectorAll(".floor-pill-btn, .floor-btn").forEach(b => {
                b.classList.toggle("active", b.dataset.floor === "ALL");
            });
        } else if (floorsInvolved && floorsInvolved.length > 0) {
            const f = floorsInvolved[0].toString();
            this.setFloorView(f);
            document.querySelectorAll(".floor-pill-btn, .floor-btn").forEach(b => {
                b.classList.toggle("active", b.dataset.floor === f);
            });
        }

        // Adjust Z for stacked view if active
        const isStacked = (this.currentFloorView === "ALL");
        const getZ = (x, y, origZ) => {
            if (!isStacked) return 0.45;
            if (origZ > 7.0) return 11.45;
            if (origZ > 2.0) return 5.95;
            return 0.45;
        };

        const curvePoints = path3D.map(p => new THREE.Vector3(p[0], p[1], getZ(p[0], p[1], p[2])));
        const curve = new THREE.CatmullRomCurve3(curvePoints);
        curve.curveType = "catmullrom";
        curve.tension = 0.2;

        const tubeGeom = new THREE.TubeGeometry(curve, Math.max(curvePoints.length * 4, 8), 0.35, 8, false);
        const tubeMat = new THREE.MeshStandardMaterial({
            color: 0x0284c7, // Vibrant electric blue
            emissive: 0x0ea5e9, // Luminous cyan highlight
            emissiveIntensity: 0.9,
            roughness: 0.15
        });

        this.routeMesh = new THREE.Mesh(tubeGeom, tubeMat);
        this.scene.add(this.routeMesh);

        // Start marker pin (Green)
        const startPos = curvePoints[0];
        this.startPin = this.createPinMarker(startPos, 0x10b981, "Start");
        this.scene.add(this.startPin);

        // Destination marker pin (Red)
        const destPos = curvePoints[curvePoints.length - 1];
        this.destPin = this.createPinMarker(destPos, 0xef4444, "Destination");
        this.scene.add(this.destPin);

        // Automatically smoothly zoom into the active navigation route!
        this.zoomToRoute(path3D);
    }

    zoomToRoute(path3D) {
        if (!path3D || path3D.length < 2) return;
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        path3D.forEach(p => {
            if (p[0] < minX) minX = p[0];
            if (p[0] > maxX) maxX = p[0];
            if (p[1] < minY) minY = p[1];
            if (p[1] > maxY) maxY = p[1];
        });

        const cx = (minX + maxX) / 2.0;
        const cy = (minY + maxY) / 2.0;
        const span = Math.max(maxX - minX, maxY - minY, 14);

        const isStacked = (this.currentFloorView === "ALL");
        const zLevel = isStacked ? 6.0 : 1.0;

        // Set camera target lookAt
        this.targetLookAt.set(cx, cy, zLevel);

        // Set close-up focus camera distance
        const camDist = Math.max(20, Math.min(span * 1.3, 38));
        this.targetCamPos.set(cx, cy - camDist * 0.72, zLevel + camDist * 0.85);

        this.isFocusing = true;
    }

    updateLiveUserLocation(userCoord, remainingPath3D) {
        if (!userCoord) return;
        const isStacked = (this.currentFloorView === "ALL");
        const getZ = (x, y, origZ) => {
            if (!isStacked) return 0.5;
            if (origZ > 7.0) return 11.5;
            if (origZ > 2.0) return 6.0;
            return 0.5;
        };
        const uz = getZ(userCoord[0], userCoord[1], userCoord[2] || 0);

        // 1. Create or move live user marker
        if (!this.userMarker) {
            this.userMarker = this.createUserMarker();
            this.scene.add(this.userMarker);
        }
        this.userMarker.position.set(userCoord[0], userCoord[1], uz);

        // 2. Reduce the line in 3D: only draw the remaining path in front of user!
        if (remainingPath3D && remainingPath3D.length >= 2) {
            // Orient user avatar cone toward next waypoint
            const nextPt = remainingPath3D[1];
            const headingDx = nextPt[0] - userCoord[0];
            const headingDy = nextPt[1] - userCoord[1];
            if (Math.hypot(headingDx, headingDy) > 0.1) {
                const headingAngle = Math.atan2(headingDy, headingDx) - Math.PI / 2;
                this.userMarker.rotation.z = headingAngle;
            }

            // Filter out duplicate or excessively close points to avoid CatmullRom singularities
            const cleanPoints = [];
            for (let i = 0; i < remainingPath3D.length; i++) {
                const pt = remainingPath3D[i];
                const v = new THREE.Vector3(pt[0], pt[1], getZ(pt[0], pt[1], pt[2]));
                if (cleanPoints.length === 0 || cleanPoints[cleanPoints.length - 1].distanceTo(v) > 0.25) {
                    cleanPoints.push(v);
                }
            }

            if (cleanPoints.length >= 2) {
                if (this.routeMesh) {
                    this.scene.remove(this.routeMesh);
                    if (this.routeMesh.geometry) {
                        this.routeMesh.geometry.dispose();
                    }
                    this.routeMesh = null;
                }

                const curve = new THREE.CatmullRomCurve3(cleanPoints);
                curve.curveType = "catmullrom";
                curve.tension = 0.2;

                const tubeGeom = new THREE.TubeGeometry(curve, Math.max(cleanPoints.length * 3, 6), 0.35, 8, false);
                this.routeMesh = new THREE.Mesh(tubeGeom, this.routeMaterial);
                this.scene.add(this.routeMesh);

                // Move start pin along with user
                if (this.startPin) {
                    this.startPin.position.set(userCoord[0], userCoord[1], uz);
                }
            }
        } else if (remainingPath3D && remainingPath3D.length < 2) {
            // Reached destination: remove route tube
            if (this.routeMesh) {
                this.scene.remove(this.routeMesh);
                if (this.routeMesh.geometry) {
                    this.routeMesh.geometry.dispose();
                }
                this.routeMesh = null;
            }
        }

        // 3. Follow user location with camera smoothly and promptly
        if (!this.isFocusing) {
            this.controls.target.lerp(new THREE.Vector3(userCoord[0], userCoord[1], uz), 0.18);
        }
    }

    createUserMarker() {
        const group = new THREE.Group();

        // Glowing Blue Avatar Sphere
        const sphereGeom = new THREE.SphereGeometry(0.7, 16, 16);
        const sphereMat = new THREE.MeshStandardMaterial({
            color: 0x2563eb,
            emissive: 0x3b82f6,
            emissiveIntensity: 0.85,
            roughness: 0.2
        });
        const sphere = new THREE.Mesh(sphereGeom, sphereMat);
        sphere.position.z = 1.0;
        group.add(sphere);

        // Direction Indicator Cone
        const coneGeom = new THREE.ConeGeometry(0.35, 1.0, 16);
        coneGeom.rotateX(Math.PI / 2);
        const coneMat = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            emissive: 0xffffff,
            emissiveIntensity: 0.6
        });
        const cone = new THREE.Mesh(coneGeom, coneMat);
        cone.position.set(0, 0.8, 1.0);
        group.add(cone);

        // Ground Radar Pulse Ring
        const ringGeom = new THREE.RingGeometry(0.4, 1.4, 32);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0x3b82f6,
            transparent: true,
            opacity: 0.75,
            side: THREE.DoubleSide
        });
        const ring = new THREE.Mesh(ringGeom, ringMat);
        ring.position.z = 0.05;
        group.add(ring);
        this.userPulseRing = ring;

        return group;
    }

    createPinMarker(pos, colorHex, label) {
        const pinGroup = new THREE.Group();
        pinGroup.position.copy(pos);

        // Pin head sphere
        const sphereGeom = new THREE.SphereGeometry(0.8, 16, 16);
        const mat = new THREE.MeshStandardMaterial({
            color: colorHex,
            emissive: colorHex,
            emissiveIntensity: 0.5
        });
        const sphere = new THREE.Mesh(sphereGeom, mat);
        sphere.position.z = 2.0;
        pinGroup.add(sphere);

        // Pin needle cone
        const coneGeom = new THREE.ConeGeometry(0.4, 2.0, 16);
        coneGeom.rotateX(Math.PI);
        const cone = new THREE.Mesh(coneGeom, mat);
        cone.position.z = 1.0;
        pinGroup.add(cone);

        return pinGroup;
    }

    clearRoute() {
        if (this.routeMesh) {
            this.scene.remove(this.routeMesh);
            if (this.routeMesh.geometry) {
                this.routeMesh.geometry.dispose();
            }
            this.routeMesh = null;
        }
        if (this.startPin) {
            this.scene.remove(this.startPin);
            this.startPin = null;
        }
        if (this.destPin) {
            this.scene.remove(this.destPin);
            this.destPin = null;
        }
        if (this.userMarker) {
            this.scene.remove(this.userMarker);
            this.userMarker = null;
            this.userPulseRing = null;
        }
        this.fullPath3D = null;
        this.isFocusing = false;
    }

    resetCamera() {
        this.setFloorView(this.currentFloorView);
    }

    toggleWalls() {
        this.show3DWalls = !this.show3DWalls;
        for (const [fid, g] of Object.entries(this.floorGroups)) {
            this.scene.remove(g);
        }
        this.floorGroups = {};
        this.buildBuildingFloors();
    }

    onCanvasClick(event) {
        const rect = this.renderer.domElement.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        this.raycaster.setFromCamera(this.mouse, this.camera);
        const intersects = this.raycaster.intersectObjects(this.roomMeshes);

        if (intersects.length > 0) {
            const hitRoom = intersects[0].object.userData;
            if (hitRoom && window.onRoomSelectedInViewer) {
                window.onRoomSelectedInViewer(hitRoom);
            }
        }
    }

    animate() {
        requestAnimationFrame(() => this.animate());
        this.controls.update();

        // Smooth camera zoom-in interpolation (fast and snappy)
        if (this.isFocusing) {
            this.camera.position.lerp(this.targetCamPos, 0.12);
            this.controls.target.lerp(this.targetLookAt, 0.12);
            if (this.camera.position.distanceTo(this.targetCamPos) < 0.25) {
                this.isFocusing = false;
            }
        }

        // Pulsate radar ring around user live marker
        if (this.userPulseRing) {
            const t = (Date.now() % 1200) / 1200;
            const s = 1.0 + t * 1.5;
            this.userPulseRing.scale.set(s, s, 1.0);
            this.userPulseRing.material.opacity = (1.0 - t) * 0.8;
        }

        // Destination pin hover bounce
        if (this.destPin) {
            const time = Date.now() * 0.005;
            this.destPin.position.z += Math.sin(time) * 0.015;
        }

        this.renderer.render(this.scene, this.camera);
    }
}

window.BuildingViewer3D = BuildingViewer3D;
