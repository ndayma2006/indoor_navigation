// ==========================================================================
// Campus Compass – SITCOE 2D Floor Plan Canvas Viewer
// Synchronized high-precision architectural floor plan representation
// ==========================================================================

class FloorPlan2DViewer {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext("2d");

        this.currentFloor = 1; // Default to Floor 1 (CSE)
        this.rooms = [];
        this.cadGeometry = null;
        this.routePath = null;
        this.floorsInvolved = [];
        this.userPos = null;
        this.userHeading = 0; // In radians (CAD coordinates)
        this.isNavigating = false;
        this.followUser = true;

        // Pan and Zoom
        this.scale = 10.0; // Pixels per meter
        this.panX = 50.0;
        this.panY = 50.0;
        this.isDragging = false;
        this.lastMouse = { x: 0, y: 0 };

        this.init();
    }

    init() {
        this.resize();
        window.addEventListener("resize", () => this.resize());

        // Mouse pan & zoom listeners
        this.canvas.addEventListener("mousedown", (e) => this.onMouseDown(e));
        window.addEventListener("mousemove", (e) => this.onMouseMove(e));
        window.addEventListener("mouseup", () => this.onMouseUp());
        this.canvas.addEventListener("wheel", (e) => this.onWheel(e));

        // Touch listeners for mobile support
        this.canvas.addEventListener("touchstart", (e) => this.onTouchStart(e), { passive: false });
        window.addEventListener("touchmove", (e) => this.onTouchMove(e), { passive: false });
        window.addEventListener("touchend", () => this.onTouchEnd());

        // Click / Tap on room
        this.canvas.addEventListener("click", (e) => this.onClick(e));
    }

    resize() {
        if (!this.canvas) return;
        this.canvas.width = this.canvas.parentElement.clientWidth;
        this.canvas.height = this.canvas.parentElement.clientHeight;
        if (!this.isNavigating) {
            this.centerView();
        }
        this.draw();
    }

    centerView() {
        const w = this.canvas.width;
        const h = this.canvas.height;
        const fitScale = Math.min((w - 80) / 66.0, (h - 80) / 66.0);
        this.scale = Math.max(6.5, fitScale);
        this.panX = (w - 65.14 * this.scale) / 2.0;
        this.panY = (h - 65.44 * this.scale) / 2.0;
    }

    setCADGeometry(cadData) {
        this.cadGeometry = cadData;
        this.draw();
    }

    setRooms(roomsList) {
        this.rooms = roomsList;
        this.draw();
    }

    setFloor(floorId) {
        this.currentFloor = parseInt(floorId) || 0;
        this.draw();
    }

    startAnimation() {
        if (this._animId) return;
        const loop = () => {
            if (this.isNavigating || this.userPos) {
                this.draw();
                this._animId = requestAnimationFrame(loop);
            } else {
                this._animId = null;
            }
        };
        this._animId = requestAnimationFrame(loop);
    }

    setRoute(path3D, floorsInvolved) {
        this.routePath = path3D;
        this.floorsInvolved = floorsInvolved || [];
        this.followUser = true;
        this.zoomToRoute(path3D);
        this.startAnimation();
        this.draw();
    }

    zoomToRoute(path3D) {
        if (!path3D || path3D.length < 2) return;
        let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
        path3D.forEach(p => {
            if (p[0] < minX) minX = p[0];
            if (p[0] > maxX) maxX = p[0];
            if (p[1] < minY) minY = p[1];
            if (p[1] > maxY) maxY = p[1];
        });

        const w = this.canvas.width;
        const h = this.canvas.height;
        const spanX = Math.max(maxX - minX, 12);
        const spanY = Math.max(maxY - minY, 12);

        // Zoom scale with comfortable framing
        const fitScale = Math.min((w - 140) / spanX, (h - 160) / spanY);
        this.scale = Math.max(10.0, Math.min(fitScale, 22.0));

        const cx = (minX + maxX) / 2.0;
        const cy = (minY + maxY) / 2.0;
        this.panX = w / 2.0 - cx * this.scale;
        this.panY = (h * 0.58) - (65.44 - cy) * this.scale;
        this.isNavigating = true;
        this.followUser = true;

        const recenterBtn = document.getElementById("gmapsRecenterBtn");
        if (recenterBtn) recenterBtn.style.display = "none";

        this.startAnimation();
    }

    updateLiveUserLocation(coord, remainingPath, heading) {
        if (!coord) return;
        this.userPos = { x: coord[0], y: coord[1], floor: coord[2] || 0 };
        this.routePath = remainingPath || [];

        if (heading !== undefined && heading !== null && !isNaN(heading)) {
            this.userHeading = heading;
        }

        // Google Maps Camera Follow: smooth lerp keeping user at ~60% down screen
        if (this.isNavigating && this.followUser) {
            const targetPanX = this.canvas.width / 2.0 - coord[0] * this.scale;
            const targetPanY = (this.canvas.height * 0.60) - (65.44 - coord[1]) * this.scale;
            this.panX += (targetPanX - this.panX) * 0.26;
            this.panY += (targetPanY - this.panY) * 0.26;
        }

        this.startAnimation();
        this.draw();
    }

    recenter() {
        this.followUser = true;
        const recenterBtn = document.getElementById("gmapsRecenterBtn");
        if (recenterBtn) recenterBtn.style.display = "none";

        if (this.userPos) {
            const w = this.canvas.width;
            const h = this.canvas.height;
            this.scale = Math.max(14.0, this.scale);
            this.panX = w / 2.0 - this.userPos.x * this.scale;
            this.panY = (h * 0.60) - (65.44 - this.userPos.y) * this.scale;
        } else if (this.routePath && this.routePath.length > 0) {
            this.zoomToRoute(this.routePath);
        } else {
            this.centerView();
        }
        this.draw();
    }

    clearRoute() {
        this.routePath = null;
        this.floorsInvolved = [];
        this.userPos = null;
        this.isNavigating = false;
        this.followUser = true;

        const recenterBtn = document.getElementById("gmapsRecenterBtn");
        if (recenterBtn) recenterBtn.style.display = "none";

        if (this._animId) {
            cancelAnimationFrame(this._animId);
            this._animId = null;
        }
        this.centerView();
        this.draw();
    }

    worldToScreen(x, y) {
        // Y in CAD is UP, Canvas Y is DOWN
        const sx = this.panX + x * this.scale;
        const sy = this.panY + (65.44 - y) * this.scale;
        return { x: sx, y: sy };
    }

    screenToWorld(sx, sy) {
        const x = (sx - this.panX) / this.scale;
        const y = 65.44 - ((sy - this.panY) / this.scale);
        return { x: x, y: y };
    }

    draw() {
        const ctx = this.ctx;
        const w = this.canvas.width;
        const h = this.canvas.height;

        ctx.clearRect(0, 0, w, h);

        // 1. Google Maps Base Neutral Canvas Background
        ctx.fillStyle = "#f1f3f4";
        ctx.fillRect(0, 0, w, h);

        // 2. Building Footprint (65.14m × 65.44m) in crisp white with subtle border
        const pTL = this.worldToScreen(0, 65.44);
        const pBR = this.worldToScreen(65.14, 0);

        ctx.fillStyle = "#ffffff";
        ctx.fillRect(pTL.x, pTL.y, (pBR.x - pTL.x), (pBR.y - pTL.y));

        ctx.strokeStyle = "#dadce0";
        ctx.lineWidth = 1.8;
        ctx.strokeRect(pTL.x, pTL.y, (pBR.x - pTL.x), (pBR.y - pTL.y));

        // 3. Central Open Courtyard (O.T.S. 33.18m × 21.58m) in Google Maps park green
        const cTL = this.worldToScreen(16.0, 39.58);
        const cBR = this.worldToScreen(49.18, 18.0);
        ctx.fillStyle = "#e6f4ea"; // Google Maps park/lawn green
        ctx.fillRect(cTL.x, cTL.y, (cBR.x - cTL.x), (cBR.y - cTL.y));

        ctx.strokeStyle = "#34a853"; // Google green border
        ctx.lineWidth = 1.6;
        ctx.strokeRect(cTL.x, cTL.y, (cBR.x - cTL.x), (cBR.y - cTL.y));

        // Courtyard Label
        ctx.fillStyle = "#137333";
        ctx.font = "bold 11px Outfit, sans-serif";
        ctx.textAlign = "center";
        const cCenter = this.worldToScreen(32.5, 28.8);
        ctx.fillText("🌿 OPEN COURTYARD (O.T.S.)", cCenter.x, cCenter.y - 6);
        ctx.font = "10px Outfit, sans-serif";
        ctx.fillStyle = "#1e8e3e";
        ctx.fillText("33.18m × 21.58m", cCenter.x, cCenter.y + 9);

        // 4. Continuous 3.0m Corridors (Pure White walkways)
        this.drawCorridors(ctx);

        // 5. CAD Polylines (Batched single stroke in structural blueprint line)
        if (this.cadGeometry && this.cadGeometry.layers) {
            ctx.strokeStyle = "rgba(66, 133, 244, 0.45)";
            ctx.lineWidth = 1.2;
            const planPolys = this.cadGeometry.layers["plan"] || [];
            ctx.beginPath();
            for (let j = 0; j < planPolys.length; j++) {
                const poly = planPolys[j];
                if (poly.length < 2) continue;
                const p0 = this.worldToScreen(poly[0][0], poly[0][1]);
                ctx.moveTo(p0.x, p0.y);
                for (let i = 1; i < poly.length; i++) {
                    const pi = this.worldToScreen(poly[i][0], poly[i][1]);
                    ctx.lineTo(pi.x, pi.y);
                }
            }
            ctx.stroke();
        }

        // 6. Staircases & Lift Cores
        this.drawVerticalCores(ctx);

        // 7. Rooms on current floor (Google Maps indoor pastel styling)
        const currentFloorRooms = this.rooms.filter(r => r.floor_id === this.currentFloor);
        for (const r of currentFloorRooms) {
            this.drawRoom(ctx, r);
        }

        // 8. Google Maps Turn-by-Turn Route Line with Directional Chevrons
        if (this.routePath && this.routePath.length > 1) {
            this.drawRoutePath(ctx);
        }

        // 9. Iconic Google Maps Blue Dot Location Marker with Flashlight Cone
        if (this.userPos) {
            this.drawUserMarker(ctx);
        }
    }

    drawCorridors(ctx) {
        ctx.fillStyle = "#ffffff"; // Clean bright walkways

        // South Corridor (y in [15.0, 18.0])
        const sTL = this.worldToScreen(16.0, 18.0);
        const sBR = this.worldToScreen(49.2, 15.0);
        ctx.fillRect(sTL.x, sTL.y, (sBR.x - sTL.x), (sBR.y - sTL.y));

        // West Corridor (x in [13.0, 16.0])
        const wTL = this.worldToScreen(13.0, 42.0);
        const wBR = this.worldToScreen(16.0, 18.0);
        ctx.fillRect(wTL.x, wTL.y, (wBR.x - wTL.x), (wBR.y - wTL.y));

        // North Corridor (y in [39.6, 42.6])
        const nTL = this.worldToScreen(16.0, 42.6);
        const nBR = this.worldToScreen(49.2, 39.6);
        ctx.fillRect(nTL.x, nTL.y, (nBR.x - nTL.x), (nBR.y - nTL.y));

        // East Corridor (x in [49.2, 52.2])
        const eTL = this.worldToScreen(49.2, 42.0);
        const eBR = this.worldToScreen(52.2, 18.0);
        ctx.fillRect(eTL.x, eTL.y, (eBR.x - eTL.x), (eBR.y - eTL.y));
    }

    drawVerticalCores(ctx) {
        // Staircase S1 (South-West)
        const s1Pos = this.worldToScreen(20.5 - 4.23, 7.0 + 2.25);
        ctx.fillStyle = "#fef7e0"; // Soft amber Google Maps tone
        ctx.strokeStyle = "#f9ab00";
        ctx.lineWidth = 1.5;
        ctx.fillRect(s1Pos.x, s1Pos.y, 8.47 * this.scale, 4.5 * this.scale);
        ctx.strokeRect(s1Pos.x, s1Pos.y, 8.47 * this.scale, 4.5 * this.scale);

        ctx.fillStyle = "#b06000";
        ctx.font = "bold 9px Outfit, sans-serif";
        ctx.textAlign = "center";
        const s1C = this.worldToScreen(20.5, 7.0);
        ctx.fillText("🪜 STAIRCASE S1", s1C.x, s1C.y);

        // Staircase S2 (North-East)
        const s2Pos = this.worldToScreen(48.5 - 2.6, 57.0 + 2.25);
        ctx.fillStyle = "#fef7e0";
        ctx.strokeStyle = "#f9ab00";
        ctx.fillRect(s2Pos.x, s2Pos.y, 5.2 * this.scale, 4.5 * this.scale);
        ctx.strokeRect(s2Pos.x, s2Pos.y, 5.2 * this.scale, 4.5 * this.scale);

        const s2C = this.worldToScreen(48.5, 57.0);
        ctx.fillStyle = "#b06000";
        ctx.fillText("🪜 STAIRCASE S2", s2C.x, s2C.y);

        // Lift L1
        const l1Pos = this.worldToScreen(39.9 - 0.9, 17.1 + 0.9);
        ctx.fillStyle = "#f3e8fd"; // Google Maps lavender tone
        ctx.strokeStyle = "#a142f4";
        ctx.fillRect(l1Pos.x, l1Pos.y, 1.8 * this.scale, 1.8 * this.scale);
        ctx.strokeRect(l1Pos.x, l1Pos.y, 1.8 * this.scale, 1.8 * this.scale);
        const l1C = this.worldToScreen(39.9, 17.1);
        ctx.fillStyle = "#7627bb";
        ctx.fillText("🛗 L1", l1C.x, l1C.y);
    }

    drawRoom(ctx, room) {
        const w = (room.width || 8.0) * this.scale;
        const l = (room.length || 6.65) * this.scale;
        const pos = this.worldToScreen(room.x - (room.width || 8.0) / 2.0, room.y + (room.length || 6.65) / 2.0);

        // Google Maps Indoor Pastel Palette based on department
        const dept = (room.department || "").toLowerCase();
        let fillColor = "#e8f0fe"; // Google soft blue default
        if (dept.includes("mech") || dept.includes("civil")) {
            fillColor = "#fef7e0"; // Soft warm buff
        } else if (dept.includes("library")) {
            fillColor = "#f3e8fd"; // Soft lavender
        } else if (dept.includes("admin")) {
            fillColor = "#fce8e6"; // Soft rose
        } else if (dept.includes("ar") || dept.includes("hospital")) {
            fillColor = "#e6f4ea"; // Soft green
        }

        ctx.fillStyle = fillColor;
        ctx.strokeStyle = "#dadce0";
        ctx.lineWidth = 1.2;

        ctx.fillRect(pos.x, pos.y, w, l);
        ctx.strokeRect(pos.x, pos.y, w, l);

        // Room label in dark readable text (Google Sans / Outfit)
        ctx.fillStyle = "#202124";
        ctx.font = "bold 9px Outfit, sans-serif";
        ctx.textAlign = "center";
        const center = this.worldToScreen(room.x, room.y);

        let shortName = room.name;
        if (shortName.length > 18) {
            shortName = shortName.substring(0, 16) + "...";
        }
        ctx.fillText(shortName, center.x, center.y - 2);

        if (room.room_number) {
            ctx.fillStyle = "#5f6368";
            ctx.font = "8px Outfit, sans-serif";
            ctx.fillText(`[${room.room_number}]`, center.x, center.y + 10);
        }
    }

    // ======================================================================
    // Google Maps Navigation Polyline with Directional Chevrons & Teardrop Pin
    // ======================================================================
    drawRoutePath(ctx) {
        if (!this.routePath || this.routePath.length < 2) return;

        // 1. Dark Blue Casing (Google Maps bottom stroke)
        ctx.strokeStyle = "#1557b0";
        ctx.lineWidth = 9.0;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        ctx.beginPath();
        for (let i = 0; i < this.routePath.length; i++) {
            const p = this.worldToScreen(this.routePath[i][0], this.routePath[i][1]);
            if (i === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();

        // 2. Vibrant Google Maps Navigation Blue Core
        ctx.strokeStyle = "#1a73e8";
        ctx.lineWidth = 6.5;
        ctx.stroke();

        // 3. Directional Chevrons (> > >) along route
        this.drawRouteChevrons(ctx);

        // 4. Start Departure Pin (Green Dot with white border)
        const startPt = this.worldToScreen(this.routePath[0][0], this.routePath[0][1]);
        ctx.fillStyle = "#188038";
        ctx.beginPath();
        ctx.arc(startPt.x, startPt.y, 6.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // 5. Destination Pin: Google Maps iconic Red Teardrop Pin!
        const endPt = this.worldToScreen(this.routePath[this.routePath.length - 1][0], this.routePath[this.routePath.length - 1][1]);
        this.drawGoogleMapsPin(ctx, endPt.x, endPt.y);
    }

    drawRouteChevrons(ctx) {
        ctx.save();
        ctx.strokeStyle = "rgba(255, 255, 255, 0.9)";
        ctx.lineWidth = 2.0;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        for (let i = 0; i < this.routePath.length - 1; i++) {
            const p1 = this.worldToScreen(this.routePath[i][0], this.routePath[i][1]);
            const p2 = this.worldToScreen(this.routePath[i + 1][0], this.routePath[i + 1][1]);
            const dx = p2.x - p1.x;
            const dy = p2.y - p1.y;
            const dist = Math.hypot(dx, dy);

            if (dist < 26) continue;

            const angle = Math.atan2(dy, dx);
            const numChevrons = Math.max(1, Math.floor(dist / 36));

            for (let c = 1; c <= numChevrons; c++) {
                const t = c / (numChevrons + 1);
                const cx = p1.x + t * dx;
                const cy = p1.y + t * dy;

                ctx.save();
                ctx.translate(cx, cy);
                ctx.rotate(angle);
                ctx.beginPath();
                ctx.moveTo(-4, -4);
                ctx.lineTo(2, 0);
                ctx.lineTo(-4, 4);
                ctx.stroke();
                ctx.restore();
            }
        }
        ctx.restore();
    }

    drawGoogleMapsPin(ctx, x, y) {
        ctx.save();
        // Pin Ground Drop Shadow
        ctx.fillStyle = "rgba(0, 0, 0, 0.22)";
        ctx.beginPath();
        ctx.ellipse(x, y + 2, 7, 3, 0, 0, Math.PI * 2);
        ctx.fill();

        // Red Teardrop Pin
        const pinH = 26;
        const pinR = 9;
        const topCY = y - pinH + pinR;

        ctx.fillStyle = "#ea4335";
        ctx.strokeStyle = "#c5221f";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.bezierCurveTo(x - pinR * 1.1, y - pinH * 0.45, x - pinR, topCY + pinR * 0.5, x - pinR, topCY);
        ctx.arc(x, topCY, pinR, Math.PI, 0, false);
        ctx.bezierCurveTo(x + pinR, topCY + pinR * 0.5, x + pinR * 1.1, y - pinH * 0.45, x, y);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // Pure white inner circle in pin head
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(x, topCY, 3.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }

    // ======================================================================
    // Iconic Google Maps Blue Dot with Flashlight Heading Cone
    // ======================================================================
    drawUserMarker(ctx) {
        if (!this.userPos) return;
        const p = this.worldToScreen(this.userPos.x, this.userPos.y);

        // Screen heading angle: in world CAD, Y is UP; on canvas screen, Y is DOWN.
        const screenAngle = -this.userHeading;
        const beamLength = 40 * Math.min(2.0, Math.max(0.8, this.scale / 10.0));
        const fovHalf = Math.PI / 6; // 30 degrees each side = 60 degrees field of view

        // 1. Forward Flashlight Heading Beam / Cone
        const grad = ctx.createRadialGradient(p.x, p.y, 4, p.x, p.y, beamLength);
        grad.addColorStop(0, "rgba(66, 133, 244, 0.45)");
        grad.addColorStop(0.65, "rgba(66, 133, 244, 0.16)");
        grad.addColorStop(1, "rgba(66, 133, 244, 0.0)");

        ctx.save();
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.arc(p.x, p.y, beamLength, screenAngle - fovHalf, screenAngle + fovHalf);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        // 2. Animated Radar Pulse Wave
        const pulse = (Date.now() % 1500) / 1500;
        const pulseRadius = 9 + pulse * 24;
        ctx.strokeStyle = `rgba(66, 133, 244, ${0.45 * (1 - pulse)})`;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(p.x, p.y, pulseRadius, 0, Math.PI * 2);
        ctx.stroke();

        // 3. Drop Shadow for depth
        ctx.save();
        ctx.shadowColor = "rgba(0, 0, 0, 0.25)";
        ctx.shadowBlur = 6;
        ctx.shadowOffsetY = 2;

        // 4. Pure White Casing Ring
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(p.x, p.y, 9.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // 5. Google Maps Blue Center
        ctx.fillStyle = "#1a73e8";
        ctx.beginPath();
        ctx.arc(p.x, p.y, 6.5, 0, Math.PI * 2);
        ctx.fill();

        // 6. Micro White Reflection Highlight
        ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
        ctx.beginPath();
        ctx.arc(p.x - 1.5, p.y - 1.5, 1.8, 0, Math.PI * 2);
        ctx.fill();
    }

    // ======================================================================
    // Pan, Zoom & Interaction Handlers
    // ======================================================================
    onMouseDown(e) {
        this.isDragging = true;
        this.lastMouse = { x: e.clientX, y: e.clientY };
    }

    onMouseMove(e) {
        if (!this.isDragging) return;
        const dx = e.clientX - this.lastMouse.x;
        const dy = e.clientY - this.lastMouse.y;
        this.panX += dx;
        this.panY += dy;
        this.lastMouse = { x: e.clientX, y: e.clientY };

        // Manual pan disables automatic camera follow and shows Re-center button
        if (this.isNavigating && (Math.abs(dx) > 1 || Math.abs(dy) > 1)) {
            this.followUser = false;
            const recenterBtn = document.getElementById("gmapsRecenterBtn");
            if (recenterBtn) recenterBtn.style.display = "flex";
        }

        this.draw();
    }

    onMouseUp() {
        this.isDragging = false;
    }

    onTouchStart(e) {
        if (e.touches.length === 1) {
            this.isDragging = true;
            this.lastMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };
        }
    }

    onTouchMove(e) {
        if (!this.isDragging || e.touches.length !== 1) return;
        e.preventDefault();
        const dx = e.touches[0].clientX - this.lastMouse.x;
        const dy = e.touches[0].clientY - this.lastMouse.y;
        this.panX += dx;
        this.panY += dy;
        this.lastMouse = { x: e.touches[0].clientX, y: e.touches[0].clientY };

        if (this.isNavigating) {
            this.followUser = false;
            const recenterBtn = document.getElementById("gmapsRecenterBtn");
            if (recenterBtn) recenterBtn.style.display = "flex";
        }

        this.draw();
    }

    onTouchEnd() {
        this.isDragging = false;
    }

    onWheel(e) {
        e.preventDefault();
        const zoomFactor = e.deltaY < 0 ? 1.12 : 0.88;
        const rect = this.canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        this.panX = mouseX - (mouseX - this.panX) * zoomFactor;
        this.panY = mouseY - (mouseY - this.panY) * zoomFactor;
        this.scale *= zoomFactor;
        this.scale = Math.max(3.0, Math.min(45.0, this.scale));

        this.draw();
    }

    onClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        const world = this.screenToWorld(mx, my);

        // Find clicked room
        const currentRooms = this.rooms.filter(r => r.floor_id === this.currentFloor);
        for (const r of currentRooms) {
            const halfW = (r.width || 8.0) / 2.0;
            const halfL = (r.length || 6.65) / 2.0;
            if (world.x >= r.x - halfW && world.x <= r.x + halfW &&
                world.y >= r.y - halfL && world.y <= r.y + halfL) {
                if (window.onRoomSelectedInViewer) {
                    window.onRoomSelectedInViewer(r);
                }
                break;
            }
        }
    }
}

window.FloorPlan2DViewer = FloorPlan2DViewer;

