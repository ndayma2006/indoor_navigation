// ==========================================================================
// Campus Compass – SITCOE Main Orchestrator
// Connects UI, Search, Routing, 3D Viewer, 2D Floor Plan, and AI Assistant
// ==========================================================================

document.addEventListener("DOMContentLoaded", async () => {
    // Instantiate 3D and 2D Viewers
    const viewer3D = new BuildingViewer3D("canvas3d-container");
    const viewer2D = new FloorPlan2DViewer("floorPlan2dCanvas");
    const assistant = new CampusAssistantClient();

    // App State
    let allRooms = [];
    let allFloors = [];
    let currentDeptFilter = "ALL";
    let activeRouteData = null;

    // UI Elements
    const searchInput = document.getElementById("searchInput");
    const btnClearSearch = document.getElementById("btnClearSearch");
    const suggestionsList = document.getElementById("suggestionsList");

    const startSelect = document.getElementById("startPointSelect");
    const destSelect = document.getElementById("destinationSelect");
    const btnCalculateRoute = document.getElementById("btnCalculateRoute");
    const btnResetNavigation = document.getElementById("btnResetNavigation");

    const directionsCard = document.getElementById("directionsCard");
    const routeDestTitle = document.getElementById("routeDestTitle");
    const routeMetaInfo = document.getElementById("routeMetaInfo");
    const staircaseBanner = document.getElementById("staircaseBanner");
    const staircaseBannerText = document.getElementById("staircaseBannerText");
    const turnStepsList = document.getElementById("turnStepsList");

    const btnMode3D = document.getElementById("btnMode3D");
    const btnMode2D = document.getElementById("btnMode2D");
    const container3D = document.getElementById("canvas3d-container");
    const container2D = document.getElementById("canvas2d-container");

    const hudFloorName = document.getElementById("hudFloorName");
    const btnCADReportModal = document.getElementById("btnCADReportModal");
    const cadModal = document.getElementById("cadModal");
    const btnCloseCADModal = document.getElementById("btnCloseCADModal");
    const cadModalContent = document.getElementById("cadModalContent");

    const btnHeaderAIChat = document.getElementById("btnHeaderAIChat");
    const btnCloseAIPanel = document.getElementById("btnCloseAIPanel");
    const btnResetCamera = document.getElementById("btnResetCamera");
    const btnToggleWalls = document.getElementById("btnToggleWalls");

    // ==========================================================================
    // 1. Load Initial Campus & CAD Data
    // ==========================================================================
    try {
        // Load floors
        const floorsResp = await fetch("/api/floors");
        allFloors = await floorsResp.json();

        // Load rooms
        const roomsResp = await fetch("/api/rooms");
        allRooms = await roomsResp.json();

        // Populate dropdowns
        populateDropdowns();

        // Load CAD geometry into 3D viewer & 2D canvas
        await viewer3D.loadCADGeometry();
        viewer3D.populateRoomMarkers(allRooms);

        const geomResp = await fetch("/api/cad/geometry");
        const geomData = await geomResp.json();
        viewer2D.setCADGeometry(geomData);
        viewer2D.setRooms(allRooms);
        viewer2D.setFloor(1); // Default to First Floor (CSE)

    } catch (err) {
        console.error("Initialization error:", err);
    }

    function populateDropdowns() {
        startSelect.innerHTML = "";
        destSelect.innerHTML = `<option value="">-- Select Destination --</option>`;

        // Add Main Entrance first as prominent starting point
        const mainGate = allRooms.find(r => r.id === "MAIN_GATE");
        if (mainGate) {
            const opt = document.createElement("option");
            opt.value = mainGate.id;
            opt.textContent = `🏫 ${mainGate.name} (Ground)`;
            opt.selected = true;
            startSelect.appendChild(opt);
        }

        // Populate start and dest dropdowns grouped by floor
        allRooms.forEach(r => {
            if (r.id !== "MAIN_GATE") {
                const opt1 = document.createElement("option");
                opt1.value = r.id;
                opt1.textContent = `${r.name} (${r.floor_name || 'Floor ' + r.floor_id})`;
                startSelect.appendChild(opt1);
            }

            // Destination filtered by department if selected
            if (currentDeptFilter === "ALL" || r.department.toUpperCase() === currentDeptFilter.toUpperCase()) {
                const opt2 = document.createElement("option");
                opt2.value = r.id;
                opt2.textContent = `${r.name} [Room ${r.room_number || '-'}] - ${r.department}`;
                destSelect.appendChild(opt2);
            }
        });
    }

    // ==========================================================================
    // 2. Search Autocomplete
    // ==========================================================================
    let searchDebounce = null;
    searchInput.addEventListener("input", () => {
        const query = searchInput.value.trim();
        btnClearSearch.style.display = query ? "block" : "none";

        clearTimeout(searchDebounce);
        if (!query) {
            suggestionsList.style.display = "none";
            return;
        }

        searchDebounce = setTimeout(async () => {
            try {
                const resp = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
                const results = await resp.json();
                renderSuggestions(results);
            } catch (err) {
                console.error("Search fetch error:", err);
            }
        }, 200);
    });

    btnClearSearch.addEventListener("click", () => {
        searchInput.value = "";
        btnClearSearch.style.display = "none";
        suggestionsList.style.display = "none";
    });

    function renderSuggestions(results) {
        suggestionsList.innerHTML = "";
        if (!results || results.length === 0) {
            suggestionsList.innerHTML = `<div class="suggestion-item"><span class="suggestion-sub">No matching classrooms, labs, or faculty found</span></div>`;
            suggestionsList.style.display = "block";
            return;
        }

        results.forEach(item => {
            const div = document.createElement("div");
            div.className = "suggestion-item";
            div.innerHTML = `
                <div class="suggestion-title">${item.name}</div>
                <div class="suggestion-sub">${item.subtitle}</div>
            `;
            div.addEventListener("click", () => {
                selectDestination(item.id);
                suggestionsList.style.display = "none";
                searchInput.value = item.name;
            });
            suggestionsList.appendChild(div);
        });
        suggestionsList.style.display = "block";
    }

    // Hide suggestions when clicking outside
    document.addEventListener("click", (e) => {
        if (!searchInput.contains(e.target) && !suggestionsList.contains(e.target)) {
            suggestionsList.style.display = "none";
        }
    });

    function selectDestination(roomId) {
        destSelect.value = roomId;
        calculateRoute();
    }

    // Quick Department Filter Pills
    document.querySelectorAll(".pill-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".pill-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            currentDeptFilter = btn.dataset.dept;
            populateDropdowns();
        });
    });

    // ==========================================================================
    // 3. Navigation Route Calculation
    // ==========================================================================
    btnCalculateRoute.addEventListener("click", () => calculateRoute());

    btnResetNavigation.addEventListener("click", () => {
        viewer3D.clearRoute();
        viewer2D.clearRoute();
        directionsCard.style.display = "none";
        destSelect.value = "";
        searchInput.value = "";
        btnClearSearch.style.display = "none";
    });

    async function calculateRoute() {
        const startId = startSelect.value || "MAIN_GATE";
        const destId = destSelect.value;

        if (!destId) {
            alert("Please choose a destination room or laboratory.");
            return;
        }

        try {
            const resp = await fetch("/api/route", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    start_room_id: startId,
                    destination_room_id: destId
                })
            });

            const data = await resp.json();
            if (!data.success) {
                alert(data.message);
                return;
            }

            activeRouteData = data;
            displayRouteDirections(data);

            // Render route in 3D and 2D viewports
            viewer3D.renderRoute(data.full_path_3d, data.floors_involved);
            viewer2D.setRoute(data.full_path_3d, data.floors_involved);

        } catch (err) {
            console.error("Route calculation error:", err);
            alert("Error computing navigation route. Check server connection.");
        }
    }

    function displayRouteDirections(data) {
        routeDestTitle.textContent = `Route to ${data.destination_name}`;
        routeMetaInfo.textContent = `Distance: ${data.total_distance_meters} m • Approx: ${Math.round(data.estimated_time_seconds / 60)} min (${data.estimated_time_seconds}s)`;

        // Staircase transition alert
        if (data.floor_transitions && data.floor_transitions.length > 0) {
            const tr = data.floor_transitions[0];
            staircaseBannerText.textContent = tr.instruction;
            staircaseBanner.style.display = "flex";
        } else {
            staircaseBanner.style.display = "none";
        }

        // Render steps
        turnStepsList.innerHTML = "";
        data.steps.forEach(s => {
            const item = document.createElement("div");
            item.className = "step-item";

            let icon = "➡️";
            if (s.turn === "left") icon = "↖️";
            else if (s.turn === "right") icon = "↗️";
            else if (s.turn && s.turn.startsWith("stairs")) icon = "🪜";
            else if (s.turn && s.turn.startsWith("lift")) icon = "🛗";

            item.innerHTML = `
                <div class="step-num">${s.step_number}</div>
                <div class="step-icon">${icon}</div>
                <div class="step-details">
                    <div class="step-text">${s.instruction}</div>
                    <div class="step-distance">${s.distance_meters > 0 ? s.distance_meters + ' m' : ''}</div>
                </div>
            `;
            turnStepsList.appendChild(item);
        });

        directionsCard.style.display = "flex";
    }

    // ==========================================================================
    // 4. Viewport Mode (3D vs 2D) & Floor Selectors
    // ==========================================================================
    btnMode3D.addEventListener("click", () => {
        btnMode3D.classList.add("active");
        btnMode2D.classList.remove("active");
        container3D.style.display = "block";
        container2D.style.display = "none";
    });

    btnMode2D.addEventListener("click", () => {
        btnMode2D.classList.add("active");
        btnMode3D.classList.remove("active");
        container3D.style.display = "none";
        container2D.style.display = "block";
        viewer2D.resize();
    });

    document.querySelectorAll(".floor-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".floor-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            const floorVal = btn.dataset.floor;

            viewer3D.setFloorView(floorVal);
            if (floorVal !== "ALL") {
                viewer2D.setFloor(parseInt(floorVal));
                hudFloorName.textContent = {
                    0: "Ground Floor (Admin, Library, MECH, Civil)",
                    1: "First Floor (CSE Department, Labs 51-59)",
                    2: "Second Floor (AIDS, ECE, Electrical, AR)"
                }[floorVal] || "Floor " + floorVal;
            } else {
                hudFloorName.textContent = "All Floors (3D Multi-Floor Stack)";
            }
        });
    });

    btnResetCamera.addEventListener("click", () => viewer3D.resetCamera());
    btnToggleWalls.addEventListener("click", () => viewer3D.toggleWalls());

    // ==========================================================================
    // 5. Assistant & CAD Modal Integration
    // ==========================================================================
    btnHeaderAIChat.addEventListener("click", () => assistant.openPanel());
    btnCloseAIPanel.addEventListener("click", () => assistant.closePanel());

    // Global listener when room is clicked in 3D or 2D viewer
    window.onRoomSelectedInViewer = (room) => {
        selectDestination(room.id);
    };

    // Global listener when assistant triggers navigation
    window.onAssistantNavigationTriggered = (navData, destRoom) => {
        activeRouteData = navData;
        if (destRoom) {
            destSelect.value = destRoom.id;
        }
        displayRouteDirections(navData);
        viewer3D.renderRoute(navData.full_path_3d, navData.floors_involved);
        viewer2D.setRoute(navData.full_path_3d, navData.floors_involved);
    };

    // Global helper for prompt chips
    window.askAIPrompt = (promptText) => {
        assistant.handleUserInput(promptText);
    };

    // CAD Validation Modal
    btnCADReportModal.addEventListener("click", async () => {
        cadModal.style.display = "flex";
        cadModalContent.innerHTML = "<p>Loading verified CAD data report...</p>";

        try {
            const resp = await fetch("/api/cad/report");
            const rep = await resp.json();

            let floorsHtml = rep.floors.map(f => `
                <tr>
                    <td><strong>${f.name}</strong></td>
                    <td>${f.elevation_m.toFixed(2)} m</td>
                    <td>${f.height_m.toFixed(2)} m</td>
                    <td>${f.function}</td>
                </tr>
            `).join("");

            let notesHtml = rep.notes.map(n => `<li>${n}</li>`).join("");

            cadModalContent.innerHTML = `
                <table class="report-table">
                    <tr><th>Source CAD Drawing</th><td><code>${rep.filename}</code></td></tr>
                    <tr><th>Source CAD Format</th><td>${rep.format}</td></tr>
                    <tr><th>Coordinate Units</th><td>${rep.units}</td></tr>
                    <tr><th>Building Dimensions</th><td><strong>${rep.building_width}m</strong> Width × <strong>${rep.building_length}m</strong> Length</td></tr>
                    <tr><th>Courtyard (O.T.S.)</th><td>33.18m × 21.58m (Surrounded by 3.0m Corridors)</td></tr>
                    <tr><th>Total Primary Floors</th><td>${rep.total_floors} Levels</td></tr>
                    <tr><th>Vertical Access Cores</th><td>${rep.staircases_count} Staircases (S1 & S2) + ${rep.lift_count} Central Lift</td></tr>
                    <tr><th>Validation Status</th><td><span style="color:#10b981; font-weight:700;">✅ ${rep.validation_status}</span></td></tr>
                </table>

                <h4 style="margin-top:16px; margin-bottom:6px;">Floor Elevation Breakdown:</h4>
                <table class="report-table">
                    <thead>
                        <tr><th>Floor</th><th>Elevation</th><th>Height</th><th>Primary Department</th></tr>
                    </thead>
                    <tbody>${floorsHtml}</tbody>
                </table>

                <h4 style="margin-top:16px; margin-bottom:6px;">Verification Notes:</h4>
                <ul class="report-notes">${notesHtml}</ul>
            `;
        } catch (err) {
            cadModalContent.innerHTML = `<p style="color:#ef4444;">Failed to load CAD report: ${err}</p>`;
        }
    });

    btnCloseCADModal.addEventListener("click", () => {
        cadModal.style.display = "none";
    });
});
