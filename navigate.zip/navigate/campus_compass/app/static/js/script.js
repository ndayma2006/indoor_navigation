// ==========================================================================
// SITCOE Smart Campus Navigation - Core Client Script
// Preserving the Exact Original UI Design with Real CAD 3D/2D Indoor Routing
// ==========================================================================

let viewer3D = null;
let viewer2D = null;
let allCampusRooms = [];
let allFacultyMembers = [];
let activeDepartment = null;
let activeRoute = null;
let currentAudio = null;

// Live positioning, dynamic line reduction, and walk simulation
let liveGpsWatchId = null;
let walkSimulationTimer = null;
let isWalkSimulating = false;
let walkWaypoints = [];
let walkWaypointIndex = 0;
let arrivalAnnounced = false;
let lastPassedSegmentIndex = 0;

// Campus GPS Anchor to CAD alignment (SITCOE Main Entrance Gate)
const CAMPUS_GPS = {
    anchorLat: 16.7080137,
    anchorLng: 74.4782274,
    anchorCadX: 32.5,
    anchorCadY: 2.0,
    latToMeters: 111320,
    lngToMeters: 106600
};

// Original department display names
const deptDisplayNames = {
    "CSE": "Computer Science & Engineering",
    "MECH": "Mechanical Engineering",
    "Civil": "Civil Engineering",
    "Electrical": "Electrical Engineering",
    "ECE": "Electronics & Computer Engineering",
    "AR": "Architecture Department",
    "AIDS": "AI & Data Science",
    "Library": "Central Library",
    "Admin": "Admin & Executive Offices"
};

// Original classroom registry
const originalDepartmentRooms = {
    "CSE": { "39": "CSE_ROOM_04", "40": "CSE_ROOM_05", "41": "CSE_ROOM_06", "43": "CSE_ROOM_07", "44": "CSE_ROOM_08", "45": "CSE_ROOM_08", "60": "CSE_ROOM_38" },
    "MECH": { "21": "MECH_201", "22": "MECH_202", "23": "MECH_201" },
    "Civil": { "41": "CIVIL_301", "42": "CIVIL_301" },
    "Electrical": { "61": "ELECT_401", "62": "ELECT_401" },
    "ECE": { "81": "ECE_501", "82": "ECE_501" },
    "AR": { "101": "AR_601", "102": "AR_601" },
    "AIDS": { "111": "AIDS_701", "112": "AIDS_701" },
    "Library": { "121": "LIB_121" },
    "Admin": { "Principal's Cabin": "ADMIN_PRINCIPAL", "ED Sir's Cabin": "ADMIN_ED", "Board Room": "ADMIN_BOARD", "Main Office": "ADMIN_OFFICE", "Exam Cell": "ADMIN_EXAM", "Placement Cell": "ADMIN_PLACEMENT" }
};

// Original laboratories registry
const originalLabs = {
    "CSE": {
        "37": { name: "Back-up Generator Room", roomId: "CSE_SERVER_53E" },
        "38": { name: "VLSI & Embedded System Laboratory", roomId: "CSE_ROOM_38" },
        "42": { name: "Research & Development Center", roomId: "CSE_ROOM_08" },
        "51": { name: "Database Laboratory", roomId: "CSE_LAB_51" },
        "52": { name: "Web Technology Laboratory", roomId: "CSE_LAB_52" },
        "53A": { name: "Faculty Cabin 53A", roomId: "CSE_FACULTY_53A" },
        "53B": { name: "Faculty Cabin 53B", roomId: "CSE_FACULTY_53A" },
        "53C": { name: "Faculty Cabin 53C", roomId: "CSE_FACULTY_53A" },
        "53D": { name: "Faculty Cabin 53D", roomId: "CSE_FACULTY_53A" },
        "53E": { name: "Server Room", roomId: "CSE_SERVER_53E" },
        "54": { name: "Operating System Laboratory", roomId: "CSE_LAB_54" },
        "55": { name: "Micro Processor Laboratory", roomId: "CSE_LAB_55" },
        "56": { name: "Computer Network Laboratory", roomId: "CSE_LAB_56" },
        "57": { name: "Language Laboratory - 1", roomId: "CSE_LAB_52" },
        "58": { name: "Programming Laboratory", roomId: "CSE_LAB_58" },
        "59": { name: "Project Laboratory", roomId: "CSE_LAB_59" },
        "HOD Office": { name: "HOD Office", roomId: "CSE_HOD" },
        "Dept. Office": { name: "Department Office", roomId: "CSE_HOD" },
        "Dept. Library": { name: "Department Library", roomId: "CSE_LAB_51" }
    },
    "MECH": {
        "201": { name: "Thermal Lab", roomId: "MECH_201" },
        "202": { name: "Workshop", roomId: "MECH_202" }
    },
    "Civil": {
        "301": { name: "Survey Lab", roomId: "CIVIL_301" }
    },
    "Electrical": {
        "401": { name: "Machine Lab", roomId: "ELECT_401" }
    },
    "ECE": {
        "501": { name: "VLSI Lab", roomId: "ECE_501" }
    },
    "AR": {
        "601": { name: "Robotics Lab", roomId: "AR_601" }
    },
    "AIDS": {
        "701": { name: "AI Lab", roomId: "AIDS_701" }
    },
    "Admin": {
        "Board Room": { name: "Board Room", roomId: "ADMIN_BOARD" },
        "Exam Cell": { name: "Exam Cell Office", roomId: "ADMIN_EXAM" },
        "Placement Cell": { name: "Placement Cell Office", roomId: "ADMIN_PLACEMENT" }
    }
};

// Emergency points
const emergency = {
    "hospital": {
        "name": "Sharad Ayurved Hospital (Yadrav)",
        "phone": "02322-253000",
        "description": "Right next to the SITCOE campus.",
        "roomId": "ADMIN_OFFICE"
    },
    "police": {
        "name": "Shivaji Nagar Police Station",
        "phone": "0230-2432000",
        "description": "Police station serving the Yadrav/Ichalkaranji sector.",
        "roomId": "MAIN_GATE"
    }
};

// ==========================================================================
// Initialization on Page Load (2D Exclusive Floor Plan Viewer)
// ==========================================================================
document.addEventListener("DOMContentLoaded", async () => {
    // 1. Initialize 2D Architectural CAD Floor Plan Viewer
    viewer2D = new FloorPlan2DViewer("map2dCanvas");

    // 2. Fetch CAD geometry and database records
    await initCampusData();

    // 3. Setup event listeners
    setupSearchFeature();
    setupVoiceAssistant();
    setupAIChatbot();
    setupMapControls();
    setupGPSTracking();
});

// ==========================================================================
// 1. Load Initial Data (Fast API Cached)
// ==========================================================================
async function initCampusData() {
    try {
        const [roomsResp, geomResp, facResp] = await Promise.all([
            fetch("/api/rooms"),
            fetch("/api/cad/geometry"),
            fetch("/api/faculty")
        ]);

        const [roomsData, geomData, facData] = await Promise.all([
            roomsResp.json(),
            geomResp.json(),
            facResp.json()
        ]);

        allCampusRooms = roomsData;
        allFacultyMembers = facData;

        // Populate 2D viewer with verified CAD architectural data
        if (viewer2D) {
            viewer2D.setCADGeometry(geomData);
            viewer2D.setRooms(allCampusRooms);
            viewer2D.setFloor(1); // Default to First Floor (CSE)
        }

        // Update GPS status bar
        const statusEl = document.getElementById("trackingStatus");
        const dotEl = document.getElementById("gpsDot");
        if (statusEl && dotEl) {
            dotEl.className = "status-dot pulsing-green";
            statusEl.textContent = "Campus 2D Positioning Connected • Verified CAD Layout (65.14m × 65.44m)";
        }
    } catch (err) {
        console.error("Error loading campus CAD data:", err);
    }
}

// ==========================================================================
// 2. Department Workspace & Content Deck (Original UI Interaction)
// ==========================================================================
function selectDepartment(deptKey) {
    activeDepartment = deptKey;

    // 1. Highlight clicked department button
    const buttons = document.querySelectorAll(".dept-card");
    buttons.forEach(btn => btn.classList.remove("active"));
    const activeBtn = document.getElementById(`btn-dept-${deptKey}`);
    if (activeBtn) activeBtn.classList.add("active");

    // 2. Open workspace card panel
    const deck = document.getElementById("contentDeck");
    deck.style.display = "block";

    // Set workspace title
    document.getElementById("selectedDeptName").innerText = `${deptDisplayNames[deptKey] || deptKey} Workspace`;

    // 3. Render Classrooms List
    renderClassrooms(deptKey);

    // 4. Render Labs List
    renderLabs(deptKey);

    // 5. Render Faculty Grid
    renderFaculty(deptKey);

    // Scroll view smoothly to the workspace card
    deck.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function closeWorkspace() {
    document.getElementById("contentDeck").style.display = "none";
    const buttons = document.querySelectorAll(".dept-card");
    buttons.forEach(btn => btn.classList.remove("active"));
}

function findBestCadRoom(deptKey, roomNum, label) {
    const origMap = originalDepartmentRooms[deptKey] || {};
    if (origMap[roomNum]) {
        const found = allCampusRooms.find(r => r.id === origMap[roomNum]);
        if (found) return found;
    }
    const match = allCampusRooms.find(r => 
        r.department.toUpperCase() === deptKey.toUpperCase() && 
        (r.room_number === roomNum || r.name.toLowerCase().includes(label.toLowerCase()))
    );
    if (match) return match;
    const deptFallback = allCampusRooms.find(r => r.department.toUpperCase() === deptKey.toUpperCase());
    return deptFallback || allCampusRooms[0];
}

function renderClassrooms(deptKey) {
    const listContainer = document.getElementById("classroomsList");
    listContainer.innerHTML = "";

    const origClassrooms = originalDepartmentRooms[deptKey] || {};
    const dbRooms = allCampusRooms.filter(r => 
        r.department.toUpperCase() === deptKey.toUpperCase() && 
        (r.room_type === "Classroom" || r.room_type === "Admin" || r.room_type === "Library")
    );

    const rendered = new Set();

    // First render original defined classrooms
    for (const [roomNum, cadId] of Object.entries(origClassrooms)) {
        const isNum = !isNaN(roomNum);
        const label = isNum ? `Room ${roomNum}` : roomNum;
        rendered.add(label.toLowerCase());

        const btn = document.createElement("button");
        btn.className = "badge-btn";
        btn.innerText = label;
        btn.onclick = () => {
            const cadRoom = allCampusRooms.find(r => r.id === cadId) || findBestCadRoom(deptKey, roomNum, label);
            speakVoice(`Navigating to ${deptKey} ${label}.`);
            navigateToRoom(cadRoom.id, `${deptKey} ${label}`);
        };
        listContainer.appendChild(btn);
    }

    // Also include any specific database rooms not already rendered
    dbRooms.forEach(r => {
        const label = r.room_number ? `Room ${r.room_number}` : r.name;
        if (!rendered.has(label.toLowerCase())) {
            rendered.add(label.toLowerCase());
            const btn = document.createElement("button");
            btn.className = "badge-btn";
            btn.innerText = label;
            btn.onclick = () => {
                speakVoice(`Navigating to ${r.name}.`);
                navigateToRoom(r.id, r.name);
            };
            listContainer.appendChild(btn);
        }
    });

    if (listContainer.children.length === 0) {
        listContainer.innerHTML = "<p class='text-muted' style='padding: 10px;'>No classrooms registered.</p>";
    }
}

function renderLabs(deptKey) {
    const listContainer = document.getElementById("labsList");
    listContainer.innerHTML = "";

    const origLabs = originalLabs[deptKey] || {};
    const dbLabs = allCampusRooms.filter(r => 
        r.department.toUpperCase() === deptKey.toUpperCase() && 
        r.room_type === "Laboratory"
    );

    const rendered = new Set();

    // Render original defined labs
    for (const [labId, labData] of Object.entries(origLabs)) {
        rendered.add(labData.name.toLowerCase());
        const card = document.createElement("div");
        card.className = "lab-card";
        card.innerHTML = `
            <div class="lab-title-desc">
                <h4>${labData.name}</h4>
                <p>Room ${labId}</p>
            </div>
            <button class="btn-nav-small">Draw Path</button>
        `;
        card.querySelector(".btn-nav-small").onclick = () => {
            const targetRoomId = labData.roomId || findBestCadRoom(deptKey, labId, labData.name).id;
            speakVoice(`Navigating to ${labData.name}.`);
            navigateToRoom(targetRoomId, labData.name);
        };
        listContainer.appendChild(card);
    }

    // Render any additional DB labs
    dbLabs.forEach(l => {
        if (!rendered.has(l.name.toLowerCase())) {
            rendered.add(l.name.toLowerCase());
            const card = document.createElement("div");
            card.className = "lab-card";
            card.innerHTML = `
                <div class="lab-title-desc">
                    <h4>${l.name}</h4>
                    <p>Floor: ${l.floor_name || 'Level ' + l.floor_id} ${l.room_number ? '• Room ' + l.room_number : ''}</p>
                </div>
                <button class="btn-nav-small">Draw Path</button>
            `;
            card.querySelector(".btn-nav-small").onclick = () => {
                speakVoice(`Navigating to ${l.name}.`);
                navigateToRoom(l.id, l.name);
            };
            listContainer.appendChild(card);
        }
    });

    if (listContainer.children.length === 0) {
        listContainer.innerHTML = "<p class='text-muted' style='padding: 10px;'>No laboratories registered.</p>";
    }
}

async function renderFaculty(deptKey) {
    const listContainer = document.getElementById("facultyList");
    listContainer.innerHTML = "<div style='color:#6b7280; font-size:13px; padding:12px;'>Loading faculty directory...</div>";

    try {
        const resp = await fetch(`/api/faculty?department=${encodeURIComponent(deptKey)}`);
        const facultyList = await resp.json();
        listContainer.innerHTML = "";

        if (!facultyList || facultyList.length === 0) {
            listContainer.innerHTML = "<p class='text-muted' style='padding: 10px;'>No faculty listings available.</p>";
            return;
        }

        facultyList.forEach(fac => {
            const card = document.createElement("div");
            card.className = "faculty-card";
            const initial = fac.name.replace("Dr. ", "").replace("Prof. ", "").replace("Hon. ", "").replace("Mr. ", "").trim().charAt(0) || "F";

            card.innerHTML = `
                <div class="faculty-avatar">
                    <span class="avatar-placeholder">${initial}</span>
                </div>
                <div class="faculty-info">
                    <h4>${fac.name}</h4>
                    <p class="designation">${fac.designation}</p>
                </div>
                <div class="faculty-details">
                    <p>🔑 <strong>Cabin:</strong> ${fac.cabin_name}</p>
                    <p>📚 <strong>Subject:</strong> ${fac.subject || fac.specialization || 'Engineering'}</p>
                </div>
                <button class="btn-faculty-nav">
                    <svg viewBox="0 0 24 24" style="width:16px;height:16px;" fill="currentColor"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"/></svg>
                    <span>Navigate to Cabin</span>
                </button>
            `;

            card.querySelector(".btn-faculty-nav").onclick = () => {
                speakVoice(`Navigating to ${fac.name}'s cabin.`);
                navigateToRoom(fac.cabin_room_id, `${fac.name}'s Cabin`);
            };

            listContainer.appendChild(card);
        });
    } catch (e) {
        console.error("Error loading faculty:", e);
        listContainer.innerHTML = "<p class='text-muted'>Faculty details could not be loaded.</p>";
    }
}

// ==========================================================================
// 3. Indoor Route Calculation & Visual Display (2D Exclusive CAD Pathfinder)
// ==========================================================================

let voicedTurnApproaches = new Set();
let voicedTurnImmediate = new Set();

function getManeuverDetails(step) {
    if (!step) {
        return { icon: "↑", type: "straight", title: "Proceed Straight", spoken: "proceed straight" };
    }
    const t = (step.turn || "").toLowerCase();
    if (t === "right" || t === "sharp_right") {
        return { icon: "↱", type: "right", title: "Turn Right", spoken: "turn right" };
    }
    if (t === "left" || t === "sharp_left") {
        return { icon: "↰", type: "left", title: "Turn Left", spoken: "turn left" };
    }
    if (t === "slight_right") {
        return { icon: "↗", type: "slight_right", title: "Bear Right", spoken: "bear right" };
    }
    if (t === "slight_left") {
        return { icon: "↖", type: "slight_left", title: "Bear Left", spoken: "bear left" };
    }
    if (t.startsWith("stairs_") || t.includes("stair")) {
        const isUp = t.includes("up") || (step.instruction && step.instruction.toLowerCase().includes("up"));
        const dir = isUp ? "Up" : "Down";
        const stairName = step.staircase_id === "STAIR_S1" ? "Staircase S1" : (step.staircase_id === "STAIR_S2" ? "Staircase S2" : "Staircase");
        return { icon: "🪜", type: "stairs", title: `Take Stairs ${dir}`, spoken: `take ${stairName} ${dir.toLowerCase()} to ${step.floor_name || 'the next floor'}` };
    }
    if (t.startsWith("lift_") || t.includes("lift")) {
        const isUp = t.includes("up") || (step.instruction && step.instruction.toLowerCase().includes("up"));
        const dir = isUp ? "Up" : "Down";
        return { icon: "🛗", type: "lift", title: `Take Lift ${dir}`, spoken: `take the lift ${dir.toLowerCase()} to ${step.floor_name || 'the next floor'}` };
    }
    return { icon: "↑", type: "straight", title: "Proceed Straight", spoken: "proceed straight along the corridor" };
}

async function navigateToRoom(roomId, roomName, startId = "MAIN_GATE") {
    try {
        // Stop any currently running walk simulation
        stopWalkSimulation();
        arrivalAnnounced = false;
        lastPassedSegmentIndex = 0;
        voicedTurnApproaches.clear();
        voicedTurnImmediate.clear();

        const resp = await fetch("/api/route", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                start_room_id: startId,
                destination_room_id: roomId
            })
        });

        const data = await resp.json();
        if (!data.success) {
            alert(data.message);
            return;
        }

        activeRoute = data;

        // Display Turn-by-Turn Route Card inside the Map section
        const routeCard = document.getElementById("mapRouteCard");
        const destHeading = document.getElementById("routeDestHeading");
        const distBadge = document.getElementById("routeDistanceBadge");
        const stepsScroll = document.getElementById("routeStepsScroll");
        const stairBanner = document.getElementById("staircaseAlertBanner");
        const stairMsg = document.getElementById("staircaseAlertMessage");

        destHeading.textContent = `Route to ${roomName || data.destination_name}`;
        distBadge.textContent = `${data.total_distance_meters} m (${Math.round(data.estimated_time_seconds / 60)} min)`;

        // Staircase / Lift transition alert
        if (data.floor_transitions && data.floor_transitions.length > 0) {
            const tr = data.floor_transitions[0];
            stairMsg.textContent = tr.instruction;
            stairBanner.style.display = "flex";
        } else {
            stairBanner.style.display = "none";
        }

        // Render step rows into Google Maps expandable drawer
        stepsScroll.innerHTML = "";
        data.steps.forEach(s => {
            const row = document.createElement("div");
            row.className = "step-row";
            row.innerHTML = `
                <div class="step-num-bubble">${s.step_number}</div>
                <div class="step-dir-text">${s.instruction}</div>
                <div class="step-dist-text">${s.distance_meters > 0 ? s.distance_meters + 'm' : ''}</div>
            `;
            stepsScroll.appendChild(row);
        });

        // Show Google Maps Top Turn Banner & Bottom Trip Card
        const topBanner = document.getElementById("gmapsTopBanner");
        if (topBanner) topBanner.style.display = "flex";

        const bottomCard = document.getElementById("gmapsBottomCard");
        if (bottomCard) bottomCard.style.display = "flex";

        const destTitle = document.getElementById("gmapsDestName");
        if (destTitle) destTitle.textContent = roomName || data.destination_name;

        const mins = Math.max(1, Math.ceil(data.total_distance_meters / 75));
        const etaMins = document.getElementById("gmapsEtaMinutes");
        if (etaMins) etaMins.textContent = `${mins} min`;

        const etaDist = document.getElementById("gmapsEtaDistance");
        if (etaDist) etaDist.textContent = `${data.total_distance_meters} m`;

        const etaSecs = Math.round(data.total_distance_meters / 1.25);
        const arrDate = new Date(Date.now() + etaSecs * 1000);
        const hh = String(arrDate.getHours()).padStart(2, '0');
        const mm = String(arrDate.getMinutes()).padStart(2, '0');
        const etaClock = document.getElementById("gmapsEtaClock");
        if (etaClock) etaClock.textContent = `${hh}:${mm}`;

        // Reset Walk Simulation button state
        const walkLabel = document.getElementById("walkSimulateLabel");
        const btnSim = document.getElementById("btnSimulateWalk");
        if (walkLabel) walkLabel.textContent = "Pause Walk";
        if (btnSim) btnSim.classList.add("active");

        // Update GPS status panel text
        const statusText = document.getElementById("trackingStatus");
        if (statusText) {
            statusText.innerHTML = `📍 Live Navigating: <strong>${roomName || data.destination_name}</strong> (${data.total_distance_meters} m)`;
        }

        // Set starting floor in 2D viewer
        const startFloor = (data.floors_involved && data.floors_involved.length > 0) ? data.floors_involved[0] : 0;
        if (viewer2D) {
            viewer2D.setFloor(startFloor);
            document.querySelectorAll(".floor-pill-btn").forEach(b => {
                b.classList.toggle("active", b.dataset.floor === startFloor.toString());
            });
            viewer2D.setRoute(data.full_path_3d, data.floors_involved);
            viewer2D.zoomToRoute(data.full_path_3d);
        }

        // Position initial live beacon at start point
        if (data.full_path_3d && data.full_path_3d.length > 0) {
            const startPt = data.full_path_3d[0];
            updateUserMovement(startPt[0], startPt[1], startPt[2] || 0);
        }

        // Initial Spoken Voice Guidance
        const firstStepInst = data.steps && data.steps.length > 0 ? data.steps[0].instruction : "";
        speakVoice(`Navigating to ${roomName || data.destination_name}. Distance is ${data.total_distance_meters} meters. ${firstStepInst}`);

        // AUTOMATIC LIVE TRACKING: Automatically starts live corridor walk & turn guidance!
        startWalkSimulation();

        // Scroll to map smoothly
        document.getElementById("mapSection").scrollIntoView({ behavior: "smooth", block: "center" });

    } catch (err) {
        console.error("Navigation route error:", err);
    }
}

function clearNavigationRoute() {
    stopWalkSimulation();
    activeRoute = null;
    arrivalAnnounced = false;
    lastPassedSegmentIndex = 0;
    voicedTurnApproaches.clear();
    voicedTurnImmediate.clear();

    const topBanner = document.getElementById("gmapsTopBanner");
    if (topBanner) topBanner.style.display = "none";

    const bottomCard = document.getElementById("gmapsBottomCard");
    if (bottomCard) bottomCard.style.display = "none";

    const stepsDrawer = document.getElementById("gmapsStepsDrawer");
    if (stepsDrawer) stepsDrawer.style.display = "none";

    const recenterBtn = document.getElementById("gmapsRecenterBtn");
    if (recenterBtn) recenterBtn.style.display = "none";

    const hud = document.getElementById("liveTurnHud");
    if (hud) hud.style.display = "none";

    if (viewer2D) viewer2D.clearRoute();

    const statusText = document.getElementById("trackingStatus");
    if (statusText) {
        statusText.innerHTML = "Campus 2D Positioning Connected • Verified CAD Layout (65.14m × 65.44m)";
    }
}

// ==========================================================================
// 3.1 Live Location, Turn Guidance HUD & Dynamic Line Reduction Engine
// ==========================================================================

function convertGpsToCad(lat, lng) {
    const dLatMeters = (lat - CAMPUS_GPS.anchorLat) * CAMPUS_GPS.latToMeters;
    const dLngMeters = (lng - CAMPUS_GPS.anchorLng) * CAMPUS_GPS.lngToMeters;
    const cadX = CAMPUS_GPS.anchorCadX + dLngMeters;
    const cadY = CAMPUS_GPS.anchorCadY + dLatMeters;
    return [cadX, cadY];
}

function updateUserMovement(userX, userY, userZ = 0) {
    if (!activeRoute || !activeRoute.full_path_3d || activeRoute.full_path_3d.length < 2) {
        return;
    }

    const path = activeRoute.full_path_3d;
    const N = path.length;

    // 1. Find closest segment to user position (search forward to avoid backtracking)
    let bestSegment = lastPassedSegmentIndex;
    let minDistSq = Infinity;
    let bestT = 0;

    const searchStart = Math.max(0, lastPassedSegmentIndex - 1);
    for (let i = searchStart; i < N - 1; i++) {
        const p1 = path[i];
        const p2 = path[i + 1];
        const vx = p2[0] - p1[0];
        const vy = p2[1] - p1[1];
        const lenSq = vx * vx + vy * vy;

        let t = 0;
        if (lenSq > 0.0001) {
            t = ((userX - p1[0]) * vx + (userY - p1[1]) * vy) / lenSq;
            t = Math.max(0, Math.min(1, t));
        }

        const projX = p1[0] + t * vx;
        const projY = p1[1] + t * vy;
        const distSq = (userX - projX) * (userX - projX) + (userY - projY) * (userY - projY);

        if (distSq < minDistSq) {
            minDistSq = distSq;
            bestSegment = i;
            bestT = t;
        }
    }

    lastPassedSegmentIndex = bestSegment;

    // 2. Reduce/Trim the line behind the user: Only path ahead of user is rendered!
    const remainingPath = [[userX, userY, userZ]];
    const nextIdx = (bestT > 0.85) ? bestSegment + 2 : bestSegment + 1;

    for (let j = nextIdx; j < N; j++) {
        const lastPt = remainingPath[remainingPath.length - 1];
        const dist = Math.hypot(path[j][0] - lastPt[0], path[j][1] - lastPt[1]);
        if (dist > 0.3) {
            remainingPath.push(path[j]);
        }
    }

    // Ensure final destination point is maintained ahead of user
    const destPt = path[N - 1];
    const distToDest = Math.hypot(destPt[0] - userX, destPt[1] - userY);
    const lastP = remainingPath[remainingPath.length - 1];
    if (distToDest > 0.8 && Math.hypot(destPt[0] - lastP[0], destPt[1] - lastP[1]) > 0.3) {
        remainingPath.push(destPt);
    }

    // 3. Compute remaining distance in meters
    let remainingMeters = 0;
    if (distToDest <= 2.0) {
        remainingMeters = distToDest;
    } else {
        for (let j = 0; j < remainingPath.length - 1; j++) {
            const pA = remainingPath[j];
            const pB = remainingPath[j + 1];
            remainingMeters += Math.hypot(pB[0] - pA[0], pB[1] - pA[1]);
        }
    }

    // 4. Identify Active Step & Calculate Turn Guidance ("turn right", "turn left", "take stairs")
    let activeStepIdx = 0;
    let activeStep = activeRoute.steps ? activeRoute.steps[0] : null;
    let distToTurn = remainingMeters;

    if (activeRoute.steps && activeRoute.steps.length > 0) {
        for (let s = 0; s < activeRoute.steps.length; s++) {
            const st = activeRoute.steps[s];
            const coords = st.coordinates;
            if (!coords || coords.length === 0) continue;
            const stepEnd = coords[coords.length - 1];
            const dEnd = Math.hypot(stepEnd[0] - userX, stepEnd[1] - userY);

            if (s === activeRoute.steps.length - 1 || dEnd > 1.8) {
                activeStepIdx = s;
                activeStep = st;
                distToTurn = dEnd;
                break;
            }
        }
    }

    const nextStep = (activeRoute.steps && activeStepIdx + 1 < activeRoute.steps.length) ? activeRoute.steps[activeStepIdx + 1] : null;
    const maneuver = getManeuverDetails(activeStep);

    // 5. Automatic Floor Switching in 2D Viewer when taking stairs or moving across floors
    if (activeStep && activeStep.floor_id !== undefined && viewer2D && viewer2D.currentFloor !== activeStep.floor_id) {
        viewer2D.setFloor(activeStep.floor_id);
        document.querySelectorAll(".floor-pill-btn").forEach(b => {
            b.classList.toggle("active", b.dataset.floor === activeStep.floor_id.toString());
        });
    }

    // 6. Calculate heading and update Google Maps Top Banner
    let heading = 0;
    if (remainingPath.length >= 2) {
        const dx = remainingPath[1][0] - remainingPath[0][0];
        const dy = remainingPath[1][1] - remainingPath[0][1];
        heading = Math.atan2(dy, dx);
    } else if (bestSegment < N - 1) {
        const dx = path[bestSegment + 1][0] - path[bestSegment][0];
        const dy = path[bestSegment + 1][1] - path[bestSegment][1];
        heading = Math.atan2(dy, dx);
    }

    const gTopBanner = document.getElementById("gmapsTopBanner");
    if (gTopBanner) {
        gTopBanner.style.display = "flex";
        const gIcon = document.getElementById("gmapsTurnIcon");
        const gIconBox = document.getElementById("gmapsTurnIconBox");
        const gDist = document.getElementById("gmapsTurnDist");
        const gAction = document.getElementById("gmapsTurnAction");
        const gStreet = document.getElementById("gmapsTurnStreet");
        const gNext = document.getElementById("gmapsTurnNext");

        if (distToDest <= 3.2) {
            if (gIcon) gIcon.textContent = "🏁";
            if (gIconBox) gIconBox.className = "gmaps-turn-icon-box arrived";
            if (gDist) {
                gDist.textContent = "ARRIVED";
                gDist.classList.remove("now-alert");
            }
            if (gAction) gAction.textContent = "Destination Reached";
            if (gStreet) gStreet.textContent = `Arrived at ${activeRoute.destination_name || 'Destination'}`;
            if (gNext) gNext.textContent = "You have reached your destination.";
        } else if (distToTurn <= 3.0 && maneuver.type !== "straight") {
            if (gIcon) gIcon.textContent = maneuver.icon;
            if (gIconBox) gIconBox.className = `gmaps-turn-icon-box ${maneuver.type}`;
            if (gDist) {
                gDist.textContent = "NOW";
                gDist.classList.add("now-alert");
            }
            if (gAction) gAction.textContent = maneuver.title;
            if (gStreet) gStreet.textContent = `${maneuver.title} now`;
            if (gNext) gNext.textContent = nextStep ? `Then: ${nextStep.instruction}` : "Destination ahead";

            // Spoken voice call for immediate turn
            if (!voicedTurnImmediate.has(activeStep.step_number)) {
                voicedTurnImmediate.add(activeStep.step_number);
                speakVoice(`${maneuver.spoken} now.`);
            }
        } else {
            if (gIcon) gIcon.textContent = maneuver.icon;
            if (gIconBox) gIconBox.className = `gmaps-turn-icon-box ${maneuver.type}`;
            if (gDist) {
                gDist.textContent = `In ${Math.max(1, Math.round(distToTurn))} m`;
                gDist.classList.remove("now-alert");
            }
            if (gAction) gAction.textContent = maneuver.title;
            if (gStreet) gStreet.textContent = activeStep ? activeStep.instruction : "Proceed along corridor";
            if (gNext) gNext.textContent = nextStep ? `Then: ${nextStep.instruction}` : "Destination ahead";

            // Spoken voice warning approaching turn (~6m - 10m)
            if (distToTurn <= 10.0 && distToTurn >= 4.0 && !voicedTurnApproaches.has(activeStep.step_number) && maneuver.type !== "straight") {
                voicedTurnApproaches.add(activeStep.step_number);
                speakVoice(`In ${Math.round(distToTurn)} meters, ${maneuver.spoken}.`);
            }
        }
    }

    // 7. Update Google Maps Bottom Trip & ETA Card
    const remM = Math.max(0, Math.round(remainingMeters));
    const remMins = Math.max(1, Math.ceil(remM / 75));
    const etaMinsEl = document.getElementById("gmapsEtaMinutes");
    if (etaMinsEl) {
        etaMinsEl.textContent = (remM <= 3) ? "Arrived" : `${remMins} min`;
    }

    const etaDistEl = document.getElementById("gmapsEtaDistance");
    if (etaDistEl) {
        etaDistEl.textContent = `${remM} m`;
    }

    const etaSeconds = Math.round(remM / 1.25);
    const arrivalDate = new Date(Date.now() + etaSeconds * 1000);
    const hh = String(arrivalDate.getHours()).padStart(2, '0');
    const mm = String(arrivalDate.getMinutes()).padStart(2, '0');
    const clockEl = document.getElementById("gmapsEtaClock");
    if (clockEl) {
        clockEl.textContent = `${hh}:${mm}`;
    }

    const statusText = document.getElementById("trackingStatus");
    if (statusText && activeRoute) {
        statusText.innerHTML = `📍 Live Position: <strong>${remM} m</strong> to ${activeRoute.destination_name || 'Destination'}`;
    }

    // 8. Update Turn-by-Turn Step Card Highlighting
    updateStepProgress(activeStepIdx, activeRoute.steps ? activeRoute.steps.length : N);

    // 9. Update 2D viewport with live user beacon, heading flashlight cone, and reduced line
    if (viewer2D) {
        viewer2D.updateLiveUserLocation([userX, userY, userZ], remainingPath, heading);
    }

    // 10. Arrival Detection
    if (distToDest <= 3.2 && !arrivalAnnounced) {
        arrivalAnnounced = true;
        speakVoice(`You have arrived at ${activeRoute.destination_name || 'your destination'}.`);
        if (isWalkSimulating) {
            stopWalkSimulation();
        }
        if (statusText) {
            statusText.innerHTML = `✅ Arrived at <strong>${activeRoute.destination_name || 'Destination'}</strong>`;
        }
    }
}

function updateStepProgress(segmentIndex, totalSegments) {
    if (!activeRoute || !activeRoute.steps) return;
    const steps = activeRoute.steps;
    if (steps.length === 0) return;

    const progressFrac = Math.min(1.0, segmentIndex / Math.max(1, totalSegments - 1));
    const activeStepIndex = Math.min(steps.length - 1, Math.floor(progressFrac * steps.length));

    const stepRows = document.querySelectorAll("#routeStepsScroll .step-row");
    stepRows.forEach((row, idx) => {
        const bubble = row.querySelector(".step-num-bubble");
        if (idx < activeStepIndex) {
            row.classList.add("completed");
            row.classList.remove("active");
            if (bubble) bubble.textContent = "✓";
        } else if (idx === activeStepIndex) {
            row.classList.remove("completed");
            row.classList.add("active");
            if (bubble) bubble.textContent = (idx + 1).toString();
            row.scrollIntoView({ behavior: "smooth", block: "nearest" });
        } else {
            row.classList.remove("completed", "active");
            if (bubble) bubble.textContent = (idx + 1).toString();
        }
    });
}

// ==========================================================================
// 3.2 Live Walk Simulator (Demonstrates real-time navigation along CAD corridors)
// ==========================================================================

function toggleWalkSimulation() {
    if (isWalkSimulating) {
        stopWalkSimulation();
    } else {
        startWalkSimulation();
    }
}

let walkSpeed = 2; // Default 2x fast snappy walk

function cycleWalkSpeed() {
    if (walkSpeed === 1) walkSpeed = 2;
    else if (walkSpeed === 2) walkSpeed = 4;
    else walkSpeed = 1;

    const label = document.getElementById("walkSpeedLabel");
    if (label) {
        label.textContent = walkSpeed === 4 ? "🚀 4x" : (walkSpeed === 2 ? "⚡ 2x" : "🚶 1x");
    }
}

function startWalkSimulation() {
    if (!activeRoute || !activeRoute.full_path_3d || activeRoute.full_path_3d.length < 2) {
        alert("Please select a classroom, lab, or faculty first to start navigation.");
        return;
    }

    stopWalkSimulation();

    const rawPath = activeRoute.full_path_3d;
    walkWaypoints = [];

    // Subdivide path into ultra-smooth 0.5m walking steps
    for (let i = 0; i < rawPath.length - 1; i++) {
        const p1 = rawPath[i];
        const p2 = rawPath[i + 1];
        const dist = Math.hypot(p2[0] - p1[0], p2[1] - p1[1]);
        const steps = Math.max(1, Math.ceil(dist / 0.5));

        for (let s = 0; s < steps; s++) {
            const frac = s / steps;
            const x = p1[0] + frac * (p2[0] - p1[0]);
            const y = p1[1] + frac * (p2[1] - p1[1]);
            const z = (p1[2] || 0) + frac * ((p2[2] || 0) - (p1[2] || 0));
            walkWaypoints.push([x, y, z]);
        }
    }
    walkWaypoints.push(rawPath[rawPath.length - 1]);

    walkWaypointIndex = 0;
    isWalkSimulating = true;
    arrivalAnnounced = false;
    lastPassedSegmentIndex = 0;

    const btn = document.getElementById("btnSimulateWalk");
    const label = document.getElementById("walkSimulateLabel");
    if (btn) btn.classList.add("walking");
    if (label) label.textContent = "Pause Walk";

    // Fast 35ms interval with walkSpeed advance for ultra-fast, snappy navigation
    walkSimulationTimer = setInterval(() => {
        if (!isWalkSimulating || walkWaypointIndex >= walkWaypoints.length) {
            stopWalkSimulation();
            return;
        }

        const wp = walkWaypoints[walkWaypointIndex];
        updateUserMovement(wp[0], wp[1], wp[2]);
        walkWaypointIndex += walkSpeed;

        if (walkWaypointIndex >= walkWaypoints.length) {
            // Ensure final waypoint is processed
            const finalWp = walkWaypoints[walkWaypoints.length - 1];
            updateUserMovement(finalWp[0], finalWp[1], finalWp[2]);
            stopWalkSimulation();
        }
    }, 35);
}

function stopWalkSimulation() {
    if (walkSimulationTimer) {
        clearInterval(walkSimulationTimer);
        walkSimulationTimer = null;
    }
    isWalkSimulating = false;

    const btn = document.getElementById("btnSimulateWalk");
    const label = document.getElementById("walkSimulateLabel");
    if (btn) btn.classList.remove("walking");
    if (label) label.textContent = "Start Live Walk";
}

// ==========================================================================
// 3.3 Geolocation (Live Device GPS Sensor)
// ==========================================================================

function setupGPSTracking() {
    if (!("geolocation" in navigator)) {
        console.log("Geolocation API not available in browser.");
        return;
    }

    const options = {
        enableHighAccuracy: true,
        maximumAge: 2500,
        timeout: 10000
    };

    liveGpsWatchId = navigator.geolocation.watchPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            const [cadX, cadY] = convertGpsToCad(latitude, longitude);

            // Check if user is within campus perimeter
            if (cadX >= -80 && cadX <= 150 && cadY >= -80 && cadY <= 150) {
                const dotEl = document.getElementById("gpsDot");
                if (dotEl) dotEl.className = "status-dot pulsing-green";

                if (activeRoute && !isWalkSimulating) {
                    const currentZ = (activeRoute.full_path_3d && activeRoute.full_path_3d.length > 0)
                        ? activeRoute.full_path_3d[0][2]
                        : 0;
                    updateUserMovement(cadX, cadY, currentZ);
                }
            }
        },
        (err) => {
            console.log("GPS geolocation status:", err.message);
        },
        options
    );
}

function navigateEmergency(type) {
    const item = emergency[type];
    if (!item) return;

    speakVoice(`Navigating to ${item.name}. ${item.description}`);
    navigateToRoom(item.roomId, item.name);

    const statusText = document.getElementById("trackingStatus");
    if (statusText) {
        statusText.innerHTML = `⚠️ Emergency AI Route: <strong>${item.name}</strong>`;
    }
}

// ==========================================================================
// 4. Instant Search Bar & In-Memory Matching Engine
// ==========================================================================

function localInstantSearch(query) {
    if (!query) return [];
    const q = query.toLowerCase().trim();
    const hits = [];

    for (const r of allCampusRooms) {
        if (hits.length >= 8) break;
        const nameMatch = r.name && r.name.toLowerCase().includes(q);
        const numMatch = r.room_number && r.room_number.toLowerCase().includes(q);
        const deptMatch = r.department && r.department.toLowerCase().includes(q);
        if (nameMatch || numMatch || deptMatch) {
            hits.push({
                id: r.id,
                name: r.name,
                room_number: r.room_number,
                room_type: r.room_type,
                department: r.department,
                floor_id: r.floor_id,
                floor_name: r.floor_name,
                subtitle: `${r.room_type} • ${r.department}`
            });
        }
    }

    for (const f of allFacultyMembers) {
        if (hits.length >= 10) break;
        const nameMatch = f.name && f.name.toLowerCase().includes(q);
        const subjMatch = f.subject && f.subject.toLowerCase().includes(q);
        const deptMatch = f.department && f.department.toLowerCase().includes(q);
        if (nameMatch || subjMatch || deptMatch) {
            hits.push({
                id: f.cabin_room_id,
                name: f.name,
                room_type: "Faculty Cabin",
                department: f.department,
                subtitle: `${f.designation} • ${f.cabin_name}`
            });
        }
    }
    return hits;
}

function setupSearchFeature() {
    const searchInput = document.getElementById("searchInput");
    const btnClear = document.getElementById("btnClearSearch");
    const suggestions = document.getElementById("searchSuggestions");

    let debounceTimer = null;

    searchInput.addEventListener("input", () => {
        const query = searchInput.value.trim();
        btnClear.style.display = query ? "block" : "none";

        clearTimeout(debounceTimer);
        if (!query) {
            suggestions.style.display = "none";
            return;
        }

        // 1. Instant local in-memory rendering (0ms response time!)
        const localHits = localInstantSearch(query);
        if (localHits.length > 0) {
            renderSearchSuggestions(localHits);
        }

        // 2. Fast server fallback for multilingual / phonetic matching (50ms debounce)
        debounceTimer = setTimeout(async () => {
            try {
                const resp = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
                const results = await resp.json();
                if (results && results.length > 0) {
                    renderSearchSuggestions(results);
                }
            } catch (e) {
                console.error("Search error:", e);
            }
        }, 50);
    });

    btnClear.addEventListener("click", () => {
        searchInput.value = "";
        btnClear.style.display = "none";
        suggestions.style.display = "none";
    });

    document.addEventListener("click", (e) => {
        if (!searchInput.contains(e.target) && !suggestions.contains(e.target)) {
            suggestions.style.display = "none";
        }
    });
}

function renderSearchSuggestions(results) {
    const suggestions = document.getElementById("searchSuggestions");
    suggestions.innerHTML = "";

    if (!results || results.length === 0) {
        suggestions.innerHTML = `<div class="suggestion-item"><span style="color:#6b7280; font-size:13px; padding:6px 12px;">No classrooms, labs, or faculty found</span></div>`;
        suggestions.style.display = "block";
        return;
    }

    results.forEach(item => {
        const div = document.createElement("div");
        div.className = "suggestion-item";
        
        let icon = "📍";
        if (item.room_type === "Faculty Cabin") icon = "👨‍🏫";
        else if (item.room_type === "Laboratory") icon = "🔬";
        else if (item.room_type === "Admin") icon = "💼";
        else if (item.room_type === "Library") icon = "📚";

        div.innerHTML = `
            <span class="suggestion-icon">${icon}</span>
            <div class="suggestion-details">
                <span class="suggestion-name">${item.name}</span>
                <span class="suggestion-meta">${item.subtitle || (item.room_type + ' • ' + item.department)}</span>
            </div>
        `;

        div.addEventListener("click", () => {
            document.getElementById("searchInput").value = item.name;
            suggestions.style.display = "none";

            if (item.department && item.department !== "Campus") {
                const deptBtn = document.getElementById(`btn-dept-${item.department}`);
                if (deptBtn) {
                    document.querySelectorAll(".dept-card").forEach(b => b.classList.remove("active"));
                    deptBtn.classList.add("active");
                }
            }

            speakVoice(`Navigating to ${item.name}.`);
            navigateToRoom(item.id, item.name);
        });

        suggestions.appendChild(div);
    });
    suggestions.style.display = "block";
}

// ==========================================================================
// 5. Voice Overlay & Speech Recognition
// ==========================================================================
function setupVoiceAssistant() {
    const btnVoice = document.getElementById("btnVoiceSearch");
    const overlay = document.getElementById("voiceOverlay");
    const btnClose = document.getElementById("btnCloseVoice");
    const transcriptEl = document.getElementById("voiceTranscript");
    const langSelect = document.getElementById("voiceLanguageSelect");

    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    let rec = null;

    if (SpeechRec) {
        rec = new SpeechRec();
        rec.continuous = false;
        rec.interimResults = false;

        rec.onstart = () => {
            overlay.style.display = "flex";
            transcriptEl.textContent = "Listening...";
        };

        rec.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            transcriptEl.textContent = `"${transcript}"`;
            setTimeout(() => {
                overlay.style.display = "none";
                processVoiceQuery(transcript);
            }, 800);
        };

        rec.onerror = (e) => {
            let errorMsg = `Error: ${e.error}. Please try again.`;
            if (e.error === 'not-allowed') {
                errorMsg = "Microphone access blocked. Please allow microphone permission in your browser.";
            } else if (e.error === 'no-speech') {
                errorMsg = "No speech detected. Please speak closer to your mic.";
            }
            transcriptEl.textContent = errorMsg;
            setTimeout(() => overlay.style.display = "none", 1800);
        };
    }

    btnVoice.addEventListener("click", () => {
        if (!rec) {
            alert("Speech recognition is not supported in this browser. Please use the search bar or text AI chat.");
            return;
        }
        rec.lang = langSelect.value;
        try {
            rec.abort();
            setTimeout(() => rec.start(), 50);
        } catch (err) {
            console.error("Recognition start error:", err);
        }
    });

    btnClose.addEventListener("click", () => {
        if (rec) rec.abort();
        overlay.style.display = "none";
    });
}

async function processVoiceQuery(text) {
    document.getElementById("searchInput").value = text;
    openAIChat();
    sendChatMessage(text);
}

// ==========================================================================
// 6. AI Assistant Chat Panel
// ==========================================================================
function setupAIChatbot() {
    const btnToggle = document.getElementById("btnAIChatToggle");
    const btnClose = document.getElementById("btnCloseAIChat");
    const btnSend = document.getElementById("btnAISend");
    const chatInput = document.getElementById("aiChatInput");

    btnToggle.addEventListener("click", toggleAIChat);
    btnClose.addEventListener("click", closeAIChat);
    btnSend.addEventListener("click", () => sendChatMessage());
    chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") sendChatMessage();
    });
}

function toggleAIChat() {
    const panel = document.getElementById("aiChatPanel");
    if (panel.style.display === "none") {
        openAIChat();
    } else {
        closeAIChat();
    }
}

function openAIChat() {
    const panel = document.getElementById("aiChatPanel");
    panel.style.display = "flex";
    const chatInput = document.getElementById("aiChatInput");
    if (chatInput) chatInput.focus();
}

function closeAIChat() {
    document.getElementById("aiChatPanel").style.display = "none";
}

function setChatQuery(queryText) {
    const chatInput = document.getElementById("aiChatInput");
    chatInput.value = queryText;
    sendChatMessage();
}

async function sendChatMessage(text = null) {
    const chatInput = document.getElementById("aiChatInput");
    const messagesContainer = document.getElementById("aiChatMessages");

    const messageText = text ? text.trim() : chatInput.value.trim();
    if (!messageText) return;

    if (!text) {
        chatInput.value = "";
    }

    appendBubble(messageText, "user");
    const typingId = appendTypingIndicator();
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    const langSelect = document.getElementById("voiceLanguageSelect");
    const lang = langSelect ? langSelect.value : 'en-US';

    try {
        const resp = await fetch("/api/chat", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                message: messageText,
                current_location: "MAIN_GATE",
                language: lang
            })
        });

        const data = await resp.json();
        removeTypingIndicator(typingId);

        appendBubble(data.reply, "assistant");
        messagesContainer.scrollTop = messagesContainer.scrollHeight;

        const speakText = (data.spoken_text || data.reply).replace(/<\/?[^>]+(>|$)/g, "");
        speakVoice(speakText);

        if (data.navigation) {
            const nav = data.navigation;
            if (nav.dept) selectDepartment(nav.dept);
            navigateToRoom(nav.room_id || nav.id, nav.label || nav.name);
        }
    } catch (e) {
        removeTypingIndicator(typingId);
        appendBubble("Sorry, an error occurred while connecting to SITCOE Assistant. Check if the Python backend is running.", "assistant");
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

function appendBubble(content, sender) {
    const container = document.getElementById("aiChatMessages");
    const bubble = document.createElement("div");
    bubble.className = `chat-message ${sender}`;

    if (sender === "assistant") {
        let formatted = content.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
        formatted = formatted.replace(/\n/g, "<br>");
        bubble.innerHTML = formatted;
    } else {
        bubble.innerText = content;
    }

    container.appendChild(bubble);
}

function appendTypingIndicator() {
    const container = document.getElementById("aiChatMessages");
    const indicator = document.createElement("div");
    const id = "typing-" + Date.now();
    indicator.id = id;
    indicator.className = "chat-message assistant typing-indicator";
    indicator.innerHTML = `
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
    `;
    container.appendChild(indicator);
    return id;
}

function removeTypingIndicator(id) {
    const indicator = document.getElementById(id);
    if (indicator) indicator.remove();
}

window.isVoiceMuted = false;

function toggleMuteVoice() {
    window.isVoiceMuted = !window.isVoiceMuted;
    const icon = document.getElementById("gmapsSoundIcon");
    const btn = document.getElementById("gmapsSoundBtn");
    if (window.isVoiceMuted) {
        if (icon) icon.textContent = "🔇";
        if (btn) btn.classList.add("muted");
        if ('speechSynthesis' in window) window.speechSynthesis.cancel();
        if (currentAudio) {
            currentAudio.pause();
            currentAudio = null;
        }
    } else {
        if (icon) icon.textContent = "🔊";
        if (btn) btn.classList.remove("muted");
    }
}
window.toggleMuteVoice = toggleMuteVoice;

function recenterMap() {
    if (viewer2D) {
        viewer2D.recenter();
    }
}
window.recenterMap = recenterMap;

function toggleStepsDrawer() {
    const drawer = document.getElementById("gmapsStepsDrawer");
    const label = document.getElementById("stepsToggleLabel");
    if (!drawer) return;
    if (drawer.style.display === "none") {
        drawer.style.display = "block";
        if (label) label.textContent = "Hide Steps";
    } else {
        drawer.style.display = "none";
        if (label) label.textContent = "Steps";
    }
}
window.toggleStepsDrawer = toggleStepsDrawer;

function toggleFullscreenMap() {
    const mapSection = document.getElementById("mapSection");
    if (!mapSection) return;

    const isFs = mapSection.classList.toggle("fullscreen-mode");
    const icon = document.getElementById("fullscreenIcon");
    const chipLabel = document.getElementById("btnFsChipLabel");
    const chipIcon = document.getElementById("btnFsChipIcon");

    if (isFs) {
        if (icon) icon.textContent = "✕";
        if (chipLabel) chipLabel.textContent = "Exit Fullscreen";
        if (chipIcon) chipIcon.textContent = "✕";

        // Request browser native Fullscreen API if supported
        if (mapSection.requestFullscreen) {
            mapSection.requestFullscreen().catch(() => {});
        } else if (mapSection.webkitRequestFullscreen) {
            mapSection.webkitRequestFullscreen();
        }
    } else {
        if (icon) icon.textContent = "⛶";
        if (chipLabel) chipLabel.textContent = "Full Screen";
        if (chipIcon) chipIcon.textContent = "⛶";

        if (document.fullscreenElement) {
            document.exitFullscreen().catch(() => {});
        }
    }

    // Trigger viewer resize & redraw to fit new dimensions
    setTimeout(() => {
        if (viewer2D) {
            viewer2D.resize();
            if (viewer2D.isNavigating) {
                viewer2D.recenter();
            } else {
                viewer2D.centerView();
            }
        }
    }, 120);
}
window.toggleFullscreenMap = toggleFullscreenMap;

// Listen for browser fullscreen change (e.g. Esc key pressed)
document.addEventListener("fullscreenchange", () => {
    const mapSection = document.getElementById("mapSection");
    if (!document.fullscreenElement && mapSection && mapSection.classList.contains("fullscreen-mode")) {
        mapSection.classList.remove("fullscreen-mode");
        const icon = document.getElementById("fullscreenIcon");
        const chipLabel = document.getElementById("btnFsChipLabel");
        const chipIcon = document.getElementById("btnFsChipIcon");
        if (icon) icon.textContent = "⛶";
        if (chipLabel) chipLabel.textContent = "Full Screen";
        if (chipIcon) chipIcon.textContent = "⛶";

        setTimeout(() => {
            if (viewer2D) viewer2D.resize();
        }, 120);
    }
});

function speakVoice(phrase) {
    if (window.isVoiceMuted) return;

    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
    }
    if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
    }
    const langSelect = document.getElementById("voiceLanguageSelect");
    const lang = langSelect ? langSelect.value : 'en-US';

    let hasFallenBack = false;
    function fallbackBrowserSpeech() {
        if (hasFallenBack || window.isVoiceMuted) return;
        hasFallenBack = true;
        if ('speechSynthesis' in window) {
            const u = new SpeechSynthesisUtterance(phrase);
            u.lang = lang;
            u.rate = 1.0;
            window.speechSynthesis.speak(u);
        }
    }

    const url = `/api/tts?text=${encodeURIComponent(phrase)}&lang=${lang}`;
    const audio = new Audio(url);
    audio.onerror = () => {
        fallbackBrowserSpeech();
    };
    audio.play().then(() => {
        currentAudio = audio;
    }).catch(() => {
        fallbackBrowserSpeech();
    });
}

// ==========================================================================
// 7. Map Navigation 3D / 2D & Floor Controls
// ==========================================================================
function setupMapControls() {
    document.querySelectorAll(".floor-pill-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            document.querySelectorAll(".floor-pill-btn").forEach(b => b.classList.remove("active"));
            btn.classList.add("active");
            const floor = parseInt(btn.dataset.floor) || 0;
            if (viewer2D) {
                viewer2D.setFloor(floor);
            }
        });
    });

    // Callback when room is clicked in 2D viewer
    window.onRoomSelectedInViewer = (room) => {
        navigateToRoom(room.id, room.name);
    };
}
