import os
from fastapi import APIRouter, Query, HTTPException, Response
from fastapi.responses import JSONResponse
from typing import Optional, List, Dict, Any

from ..models.schemas import (
    NavigationRequest, NavigationResponse, AssistantQuery, AssistantResponse,
    CADValidationReport, RoomBase
)
from ..data.search_service import (
    get_all_floors, get_all_rooms, get_all_staircases, search_campus, get_room_by_id,
    get_all_faculty, get_campus_full_data
)
from ..cad.importer import CADImporter
from ..navigation.pathfinder import CampusPathfinder
from ..assistant.assistant_service import CampusAssistantService
from ..assistant.speech_service import SpeechService

router = APIRouter(prefix="/api")

# Singleton service instances
pathfinder = CampusPathfinder()
cad_importer = CADImporter()
assistant_service = CampusAssistantService(pathfinder)
speech_service = SpeechService()

@router.get("/floors")
def list_floors(response: Response):
    response.headers["Cache-Control"] = "public, max-age=3600"
    return get_all_floors()

@router.get("/rooms")
def list_rooms(response: Response, floor_id: Optional[int] = None, department: Optional[str] = None):
    response.headers["Cache-Control"] = "public, max-age=1800"
    rooms = get_all_rooms(floor_id)
    if department:
        rooms = [r for r in rooms if r["department"].lower() == department.lower()]
    return rooms

@router.get("/rooms/{room_id}")
def get_room(room_id: str, response: Response):
    response.headers["Cache-Control"] = "public, max-age=1800"
    room = get_room_by_id(room_id)
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    return room

@router.get("/staircases")
def list_staircases(response: Response):
    response.headers["Cache-Control"] = "public, max-age=3600"
    return get_all_staircases()

@router.get("/faculty")
def list_faculty(response: Response, department: Optional[str] = None):
    response.headers["Cache-Control"] = "public, max-age=1800"
    return get_all_faculty(department)

@router.get("/data")
def get_data():
    return get_campus_full_data()

@router.get("/search")
def search(q: str = Query(..., min_length=1)):
    return search_campus(q, limit=8)

@router.post("/route", response_model=NavigationResponse)
def calculate_route(request: NavigationRequest):
    return pathfinder.find_path(request)

@router.post("/assistant/chat", response_model=AssistantResponse)
def chat_assistant(query: AssistantQuery):
    return assistant_service.process_query(query)

@router.post("/chat")
def chat_compat(payload: Dict[str, Any]):
    # Compatibility with original /api/chat endpoint
    msg = payload.get("message") or payload.get("query") or ""
    current_loc = payload.get("current_location", "MAIN_GATE")
    lang = payload.get("language", "en-US")
    
    q = AssistantQuery(query=msg, current_location=current_loc, language=lang)
    resp = assistant_service.process_query(q)
    
    nav = None
    if resp.navigation and resp.navigation.success and resp.destination_room:
        nav = {
            "room_id": resp.destination_room.id,
            "label": resp.destination_room.name,
            "coord": [resp.destination_room.x, resp.destination_room.y],
            "floor_id": resp.destination_room.floor_id,
            "color": resp.destination_room.color
        }
    
    return {
        "reply": resp.reply_text,
        "spoken_text": resp.spoken_text,
        "navigation": nav,
        "details": resp
    }

@router.get("/tts")
async def text_to_speech(text: str = Query(..., min_length=1), lang: str = "en-US"):
    try:
        audio_bytes = await speech_service.generate_speech_bytes(text, lang)
        if audio_bytes:
            return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception:
        pass
    raise HTTPException(status_code=503, detail="Speech service temporarily unavailable; client speech synthesis fallback active.")

@router.get("/cad/report", response_model=CADValidationReport)
def get_cad_validation_report(response: Response):
    response.headers["Cache-Control"] = "public, max-age=7200"
    return cad_importer.generate_validation_report()

@router.get("/cad/geometry")
def get_cad_geometry(response: Response):
    response.headers["Cache-Control"] = "public, max-age=7200"
    return cad_importer.load_geometry()
