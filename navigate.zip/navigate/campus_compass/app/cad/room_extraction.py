from typing import List, Dict, Any, Optional
from ..data.search_service import get_all_rooms, get_room_by_id
from .geometry import distance_2d, point_in_polygon

class RoomExtractor:
    def __init__(self):
        pass

    def get_rooms_by_floor(self, floor_id: int) -> List[Dict[str, Any]]:
        return get_all_rooms(floor_id)

    def get_room_polygon(self, room: Dict[str, Any]) -> List[List[float]]:
        """Generates the 2D bounding polygon points for a room based on its position and dimensions."""
        x, y = room["x"], room["y"]
        w = room.get("width") or 8.0
        l = room.get("length") or 6.65
        
        # Center the box around (x, y)
        half_w = w / 2.0
        half_l = l / 2.0
        return [
            [round(x - half_w, 2), round(y - half_l, 2)],
            [round(x + half_w, 2), round(y - half_l, 2)],
            [round(x + half_w, 2), round(y + half_l, 2)],
            [round(x - half_w, 2), round(y + half_l, 2)],
            [round(x - half_w, 2), round(y - half_l, 2)]
        ]

    def find_nearest_room(self, x: float, y: float, floor_id: int) -> Optional[Dict[str, Any]]:
        rooms = self.get_rooms_by_floor(floor_id)
        if not rooms:
            return None
        closest = min(rooms, key=lambda r: distance_2d((x, y), (r["x"], r["y"])))
        return closest
