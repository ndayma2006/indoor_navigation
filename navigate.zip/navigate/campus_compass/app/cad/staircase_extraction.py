from typing import List, Dict, Any, Optional
from ..data.search_service import get_all_staircases

class StaircaseExtractor:
    def __init__(self):
        pass

    def get_staircases(self) -> List[Dict[str, Any]]:
        return get_all_staircases()

    def get_staircase_by_id(self, stair_id: str) -> Optional[Dict[str, Any]]:
        stairs = self.get_staircases()
        for s in stairs:
            if s["id"] == stair_id:
                return s
        return None

    def get_landing_point(self, stair_id: str, floor_id: int) -> Optional[Dict[str, float]]:
        stair = self.get_staircase_by_id(stair_id)
        if not stair or floor_id not in stair.get("floors_connected", []):
            return None
        
        # Elevation per floor: Floor 0 = 0.0m, Floor 1 = 4.95m, Floor 2 = 9.00m
        elevations = {0: 0.0, 1: 4.95, 2: 9.00}
        z = elevations.get(floor_id, 0.0)

        # Corridor connection points
        if stair_id == "STAIR_S1":
            # Connects directly to South corridor
            return {"x": 20.5, "y": 18.0, "z": z}
        elif stair_id == "STAIR_S2":
            # Connects to North corridor
            return {"x": 48.5, "y": 42.0, "z": z}
        elif stair_id == "LIFT_L1":
            # Connects to South corridor at lift door
            return {"x": 39.9, "y": 18.0, "z": z}
        
        return {"x": stair["x"], "y": stair["y"], "z": z}
