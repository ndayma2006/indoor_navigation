import re
from typing import Dict, Any, Optional, Tuple, List
from ..data.search_service import search_campus, get_all_rooms

class IntentParser:
    def __init__(self):
        pass

    def parse(self, query: str) -> Dict[str, Any]:
        q = query.strip().lower()

        # 1. Greetings
        if re.search(r'\b(hello|hi|hey|good morning|good afternoon|namaskar|namaste|नमस्कार|नमस्ते)\b', q):
            return {
                "intent": "greeting",
                "target": None,
                "confidence": 0.95,
                "reply": "Hello! I am Campus Compass AI, your SITCOE indoor navigation assistant. Ask me to find any classroom, laboratory, faculty cabin, or department!"
            }

        # 2. Help
        if re.search(r'\b(help|how to use|commands|what can you do|मदत)\b', q):
            return {
                "intent": "help",
                "target": None,
                "confidence": 0.9,
                "reply": "You can ask questions like: 'Take me to Classroom 38', 'Where is Dr. Patil's cabin?', 'How do I reach the Database Lab?', or 'Which staircase connects to the First Floor?'"
            }

        # 3. Floors / Staircases query
        if re.search(r'\b(staircase|stairs|lift|elevator|floors|how many floors|जिना|पायऱ्या|लिफ्ट)\b', q):
            if "which staircase" in q or "where is the staircase" in q:
                return {
                    "intent": "stair_info",
                    "target": None,
                    "confidence": 0.85,
                    "reply": "SITCOE has two primary staircase cores: Staircase S1 at the South-West wing (near the main entrance corridor) and Staircase S2 at the North-East wing (near the Gents toilet), plus a central passenger lift facing the courtyard."
                }
            return {
                "intent": "floor_info",
                "target": None,
                "confidence": 0.85,
                "reply": "SITCOE Main Building consists of 3 primary levels: Ground Floor (Administrative Offices, Library, MECH, Civil), First Floor (Computer Science & Engineering Department, Labs 51-59), and Second Floor (AI & Data Science, ECE, Electrical, Architecture, Seminar Hall)."
            }

        # 4. Navigation & Location intents
        # Search destination entity in database
        results = search_campus(q, limit=5)

        if not results:
            # Strip common filler prefixes
            clean_q = re.sub(r'^(take me to|navigate to|where is|how to reach|where can i find|show me|find|go to|take me|मला दाखवा|कुठे आहे|कडे जा)\s+', '', q).strip()
            results = search_campus(clean_q, limit=5)

        if results:
            best = results[0]
            # Check for genuine ambiguity across different physical rooms
            if (len(results) > 1 and 
                results[0]["id"] != results[1]["id"] and 
                abs(results[0]["score"] - results[1]["score"]) < 5 and
                results[0]["score"] < 100):
                candidates_str = ", ".join([f"'{r['name']}'" for r in results[:3]])
                return {
                    "intent": "clarification_needed",
                    "target": best,
                    "candidates": results[:3],
                    "reply": f"I found multiple matching destinations: {candidates_str}. Did you mean {best['name']}?"
                }

            return {
                "intent": "navigate",
                "target": best,
                "confidence": 0.9,
                "reply": f"I have located {best['name']} on {best['floor_name']}. Starting indoor navigation now."
            }

        # Fallback when no destination resolved
        return {
            "intent": "unknown",
            "target": None,
            "confidence": 0.2,
            "reply": f"I heard: \"{query}\". However, I couldn't find a matching classroom, lab, or faculty member in the SITCOE directory. Try stating the room number (e.g. 'Room 38') or department (e.g. 'CSE')."
        }
