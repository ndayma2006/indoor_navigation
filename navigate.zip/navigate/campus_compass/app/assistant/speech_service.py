import asyncio
import edge_tts
from typing import Optional

VOICE_MAP = {
    "en": "en-US-EmmaNeural",
    "en-US": "en-US-EmmaNeural",
    "en-IN": "en-IN-NeerjaNeural",
    "hi": "hi-IN-SwaraNeural",
    "hi-IN": "hi-IN-SwaraNeural",
    "mr": "mr-IN-AarohiNeural",
    "mr-IN": "mr-IN-AarohiNeural"
}

class SpeechService:
    def __init__(self):
        pass

    async def generate_speech_bytes(self, text: str, lang: str = "en-US") -> Optional[bytes]:
        if not text or not text.strip():
            return None

        clean_lang = lang.strip().lower()
        voice = "en-US-EmmaNeural"
        for prefix, v in VOICE_MAP.items():
            if clean_lang.startswith(prefix.lower()):
                voice = v
                break

        try:
            communicate = edge_tts.Communicate(text.strip(), voice)
            audio_data = b""
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    audio_data += chunk["data"]
            return audio_data
        except Exception as e:
            print(f"SpeechService synthesis error ({e}). Returning None.")
            return None
