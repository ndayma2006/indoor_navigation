import os
import json
import re
from typing import Dict, Any, Optional
from dotenv import load_dotenv
from .intent_parser import IntentParser
from ..navigation.pathfinder import CampusPathfinder
from ..models.schemas import AssistantQuery, AssistantResponse, NavigationRequest, RoomBase
from ..data.search_service import get_room_by_id, get_all_rooms

load_dotenv()

class CampusAssistantService:
    def __init__(self, pathfinder: CampusPathfinder):
        self.parser = IntentParser()
        self.pathfinder = pathfinder
        self.api_key = os.environ.get("GEMINI_API_KEY")
        self.gemini_model = None

        if self.api_key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.gemini_model = genai.GenerativeModel("gemini-1.5-flash")
                print("Gemini AI API successfully configured in CampusAssistantService.")
            except Exception as e:
                print(f"Notice: Gemini initialization skipped ({e}). Operating in Local NLP Mode.")
                self.gemini_model = None
        else:
            print("Notice: GEMINI_API_KEY not set. Campus Compass AI operating in Local NLP Engine Mode.")

    def process_query(self, query: AssistantQuery) -> AssistantResponse:
        parsed = self.parser.parse(query.query)
        intent = parsed.get("intent", "unknown")
        target = parsed.get("target")

        nav_response = None
        destination_room = None

        if intent in ("navigate", "clarification_needed") and target:
            dest_id = target["id"]
            room_record = get_room_by_id(dest_id)
            if room_record:
                destination_room = RoomBase(**room_record)
                
                # Calculate navigation route
                start_id = query.current_location if query.current_location else "MAIN_GATE"
                nav_req = NavigationRequest(
                    start_room_id=start_id,
                    start_floor=query.current_floor or 0,
                    destination_room_id=dest_id
                )
                nav_response = self.pathfinder.find_path(nav_req)

        reply_text = parsed.get("reply", "")
        spoken_text = reply_text

        # If Gemini is configured and query is complex/conversational, enhance response
        if self.gemini_model and intent not in ("navigate", "greeting"):
            try:
                prompt = f"""
You are Campus Compass AI, the intelligent 3D indoor navigation assistant for SITCOE (Sharad Institute of Technology College of Engineering, Yadrav).
Building context:
- 3 Floors: Ground (0), First (1 - CSE Dept), Second (2 - AIDS, ECE, Electrical, AR).
- Staircase S1 (South-West) and Staircase S2 (North-East) connect all floors.
- Central passenger lift faces the south courtyard passage.
- Principal: Dr. Sanjay A. Khot (Ground floor)
- Executive Director: Hon. Anil A. Bagane (ED Sir, Ground floor)
- HOD CSE: Dr. A. B. Patil (First floor, Room 53/HOD)

User asked: "{query.query}"
Give a concise, friendly, and helpful 1-2 sentence response. If a room or lab is mentioned, guide them accurately.
"""
                resp = self.gemini_model.generate_content(prompt)
                ai_reply = resp.text.strip()
                if ai_reply:
                    reply_text = ai_reply
                    spoken_text = ai_reply
            except Exception as e:
                print(f"Gemini generation fallback to local reply: {e}")

        # Formulate audio endpoint URL
        audio_url = f"/api/tts?text={spoken_text}&lang={query.language or 'en-US'}"

        return AssistantResponse(
            reply_text=reply_text,
            spoken_text=spoken_text,
            intent=intent,
            destination_room=destination_room,
            navigation=nav_response,
            audio_url=audio_url
        )
