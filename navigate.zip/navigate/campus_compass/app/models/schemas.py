from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field

class RoomBase(BaseModel):
    id: str
    name: str
    room_number: Optional[str] = None
    floor_id: int
    floor_name: str
    department: str
    room_type: str  # Classroom, Laboratory, HOD Cabin, Faculty Cabin, Admin, Amenity, Entrance, Staircase
    x: float
    y: float
    z: float
    door_x: float
    door_y: float
    width: Optional[float] = None
    length: Optional[float] = None
    area_sqm: Optional[float] = None
    info: Optional[str] = None
    color: Optional[str] = "#3b82f6"

class FacultyMember(BaseModel):
    name: str
    designation: str
    department: str
    cabin_room_id: str
    cabin_name: str
    floor_id: int
    subject: Optional[str] = None

class Staircase(BaseModel):
    id: str
    name: str
    stair_type: str  # stairs, lift, ramp
    floors_connected: List[int]
    x: float
    y: float
    width: float
    length: float

class RouteStep(BaseModel):
    step_number: int
    floor_id: int
    floor_name: str
    instruction: str
    distance_meters: float
    turn: Optional[str] = None  # straight, left, right, stairs_up, stairs_down, lift_up, lift_down
    staircase_id: Optional[str] = None
    coordinates: List[List[float]]  # [[x, y, z], ...]

class NavigationRequest(BaseModel):
    start_room_id: Optional[str] = None
    start_coords: Optional[List[float]] = None  # [x, y, z]
    start_floor: Optional[int] = 0
    destination_room_id: str
    prefer_lift: bool = False

class NavigationResponse(BaseModel):
    success: bool
    message: str
    start_name: str
    destination_name: str
    destination_floor: int
    total_distance_meters: float
    estimated_time_seconds: int
    floor_transitions: List[Dict[str, Any]]
    steps: List[RouteStep]
    full_path_3d: List[List[float]]  # [[x,y,z], ...]
    floors_involved: List[int]

class AssistantQuery(BaseModel):
    query: str
    current_floor: Optional[int] = 0
    current_location: Optional[str] = None
    language: Optional[str] = "en-US"

class AssistantResponse(BaseModel):
    reply_text: str
    spoken_text: str
    intent: str  # navigate, locate, info, greeting, help, unknown
    destination_room: Optional[RoomBase] = None
    navigation: Optional[NavigationResponse] = None
    audio_url: Optional[str] = None

class CADValidationReport(BaseModel):
    filename: str
    format: str
    units: str
    building_width: float
    building_length: float
    total_floors: int
    floors: List[Dict[str, Any]]
    total_rooms: int
    staircases_count: int
    lift_count: int
    validation_status: str
    notes: List[str]
