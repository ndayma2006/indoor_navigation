import pytest
from fastapi.testclient import TestClient
from campus_compass.app.main import app

client = TestClient(app)

def test_api_floors():
    response = client.get("/api/floors")
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 3
    floor_names = [f["name"] for f in data]
    assert "Ground Floor" in floor_names
    assert "First Floor" in floor_names

def test_api_rooms():
    response = client.get("/api/rooms")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 20

    # Filter by floor
    f1_resp = client.get("/api/rooms?floor_id=1")
    assert f1_resp.status_code == 200
    f1_data = f1_resp.json()
    assert all(r["floor_id"] == 1 for r in f1_data)

def test_api_search():
    response = client.get("/api/search?q=patil")
    assert response.status_code == 200
    data = response.json()
    assert len(data) > 0
    assert any("Patil" in r["name"] for r in data)

def test_api_route():
    payload = {
        "start_room_id": "MAIN_GATE",
        "destination_room_id": "CSE_ROOM_04"
    }
    response = client.post("/api/route", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["total_distance_meters"] > 0
    assert len(data["steps"]) > 0
    assert len(data["full_path_3d"]) > 0

def test_api_chat_assistant():
    payload = {
        "query": "Where is the Principal Cabin?",
        "current_location": "MAIN_GATE"
    }
    response = client.post("/api/assistant/chat", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["intent"] == "navigate"
    assert data["destination_room"] is not None
    assert "Principal" in data["destination_room"]["name"]

def test_api_cad_report():
    response = client.get("/api/cad/report")
    assert response.status_code == 200
    data = response.json()
    assert "building_width" in data
    assert data["building_width"] > 60.0
    assert data["total_floors"] == 3

def test_api_cad_geometry():
    response = client.get("/api/cad/geometry")
    assert response.status_code == 200
    data = response.json()
    assert "bounds" in data
    assert "layers" in data

def test_serve_index():
    response = client.get("/")
    assert response.status_code == 200
    assert "Campus Compass" in response.text

def test_api_faculty():
    response = client.get("/api/faculty?department=CSE")
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 3
    assert any("Patil" in f["name"] for f in data)

def test_api_data():
    response = client.get("/api/data")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert "rooms" in data
    assert "faculty" in data
    assert "floors" in data

def test_api_chat_compat():
    response = client.post("/api/chat", json={"message": "Where is Dr. Patil's cabin?"})
    assert response.status_code == 200
    data = response.json()
    assert "reply" in data
    assert data["navigation"] is not None
    assert "Patil" in data["navigation"]["label"]

