import pytest
from campus_compass.app.navigation.graph_builder import CampusGraphBuilder
from campus_compass.app.navigation.pathfinder import CampusPathfinder
from campus_compass.app.models.schemas import NavigationRequest

def test_graph_builder_connectivity():
    builder = CampusGraphBuilder()
    G = builder.build_graph()

    assert G.number_of_nodes() > 50
    assert G.number_of_edges() > 50

    # Verify vertical edges exist for Staircase S1 and S2
    s1_edges = [
        (u, v) for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "stairs" and d.get("stair_id") == "STAIR_S1"
    ]
    assert len(s1_edges) >= 2  # Connects 0-1 and 1-2

    # Verify lift edges exist
    lift_edges = [
        (u, v) for u, v, d in G.edges(data=True)
        if d.get("edge_type") == "lift"
    ]
    assert len(lift_edges) >= 2

def test_single_floor_route():
    pathfinder = CampusPathfinder()
    req = NavigationRequest(
        start_room_id="MAIN_GATE",
        destination_room_id="ADMIN_PRINCIPAL"
    )
    res = pathfinder.find_path(req)
    assert res.success is True
    assert res.total_distance_meters > 0
    assert len(res.steps) > 0
    assert res.floors_involved == [0]
    assert len(res.floor_transitions) == 0

def test_multi_floor_staircase_route():
    pathfinder = CampusPathfinder()
    # Route from Ground Floor Main Entrance to First Floor CSE Room 38
    req = NavigationRequest(
        start_room_id="MAIN_GATE",
        destination_room_id="CSE_ROOM_38"
    )
    res = pathfinder.find_path(req)
    assert res.success is True
    assert res.total_distance_meters > 20.0
    assert 0 in res.floors_involved and 1 in res.floors_involved
    assert len(res.floor_transitions) >= 1
    # Check that staircase instruction is present
    stair_step = [s for s in res.steps if s.turn and s.turn.startswith("stairs")]
    assert len(stair_step) >= 1

def test_multi_floor_to_second_floor():
    pathfinder = CampusPathfinder()
    # Route from Ground Floor Main Entrance to Second Floor AIDS Room 701
    req = NavigationRequest(
        start_room_id="MAIN_GATE",
        destination_room_id="AIDS_701"
    )
    res = pathfinder.find_path(req)
    assert res.success is True
    assert 2 in res.floors_involved
    assert len(res.floor_transitions) >= 2  # 0->1 and 1->2 or direct

def test_unreachable_destination():
    pathfinder = CampusPathfinder()
    req = NavigationRequest(
        start_room_id="MAIN_GATE",
        destination_room_id="NON_EXISTENT_ROOM_XYZ"
    )
    res = pathfinder.find_path(req)
    assert res.success is False
    assert "not found" in res.message.lower()
