import pytest
from campus_compass.app.cad.geometry import distance_2d, distance_3d, point_in_polygon
from campus_compass.app.cad.importer import CADImporter

def test_geometry_primitives():
    assert distance_2d((0, 0), (3, 4)) == 5.0
    assert distance_3d([0, 0, 0], [1, 2, 2]) == 3.0

    # Test point in polygon
    poly = [[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]]
    assert point_in_polygon(5, 5, poly) is True
    assert point_in_polygon(15, 15, poly) is False

def test_cad_importer_report():
    importer = CADImporter()
    report = importer.generate_validation_report()
    assert report.total_floors == 3
    assert report.building_width > 60.0
    assert report.building_length > 60.0
    assert report.staircases_count == 2
    assert report.lift_count == 1
    assert "VERIFIED" in report.validation_status

def test_cad_geometry_loading():
    importer = CADImporter()
    geom = importer.load_geometry()
    assert "bounds" in geom
    assert "layers" in geom
    assert geom["bounds"]["max_x"] >= 65.0
