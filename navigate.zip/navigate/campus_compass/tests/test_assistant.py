import pytest
from campus_compass.app.assistant.intent_parser import IntentParser
from campus_compass.app.assistant.assistant_service import CampusAssistantService
from campus_compass.app.navigation.pathfinder import CampusPathfinder
from campus_compass.app.models.schemas import AssistantQuery

def test_intent_parser_greetings():
    parser = IntentParser()
    res = parser.parse("Hello, how are you?")
    assert res["intent"] == "greeting"
    assert "Campus Compass AI" in res["reply"]

def test_intent_parser_staircase_query():
    parser = IntentParser()
    res = parser.parse("Which staircase should I take?")
    assert res["intent"] == "stair_info"
    assert "Staircase S1" in res["reply"]

def test_intent_parser_room_navigation():
    parser = IntentParser()
    res = parser.parse("Take me to Classroom 38")
    assert res["intent"] == "navigate"
    assert res["target"] is not None
    assert "38" in res["target"]["name"] or "38" in (res["target"].get("room_number") or "")

def test_intent_parser_faculty_query():
    parser = IntentParser()
    res = parser.parse("Where is Dr. Patil's cabin?")
    assert res["intent"] == "navigate"
    assert res["target"] is not None
    assert "Patil" in res["target"]["name"]

def test_intent_parser_multilingual():
    parser = IntentParser()
    res = parser.parse("प्राचार्य केबिन कुठे आहे?")
    assert res["target"] is not None
    assert "Principal" in res["target"]["name"]

def test_assistant_service_workflow():
    pathfinder = CampusPathfinder()
    assistant = CampusAssistantService(pathfinder)
    q = AssistantQuery(query="Navigate to Database Lab", current_location="MAIN_GATE")
    res = assistant.process_query(q)
    assert res.intent == "navigate"
    assert res.destination_room is not None
    assert "Database" in res.destination_room.name
    assert res.navigation is not None
    assert res.navigation.success is True
    assert res.navigation.total_distance_meters > 0
