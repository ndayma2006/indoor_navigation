"""
Campus Compass – AI-Powered 3D Indoor Navigation System for SITCOE
Run this file to start the Python server:
    python app.py

Access the application in your browser at:
    http://localhost:8000
"""
import sys
import os
import uvicorn

if __name__ == "__main__":
    if sys.platform == "win32":
        try:
            import io
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
        except Exception:
            pass

    print("=" * 70)
    print("  CAMPUS COMPASS - SITCOE SMART CAMPUS NAVIGATION SYSTEM")
    print("  Shri Shamrao Patil Yadravkar Educational & Charitable Trust's")
    print("  Sharad Institute of Technology College of Engineering, Yadrav")
    print("=" * 70)
    print("  [*] Real SITCOE Campus CAD File: 02.Main Building Sheet with lift.dwg")
    print("  [*] Multi-Floor NetworkX Indoor Graph & Dijkstra/A* Pathfinder")
    print("  [*] Interactive 3D Building Viewer & 2D Floor Plan (65.14m x 65.44m)")
    print("  [*] Voice AI Assistant with Multi-Language Support (English, Hindi, Marathi)")
    print("  [*] Preserving the Exact Original UI Design & Fast In-Memory Caching")
    print("  [*] Live Positioning, Auto-Zoom & Dynamic Path Reduction Engine")
    print("=" * 70)
    print("  Starting server at: http://localhost:8000")
    print("  Press Ctrl+C to stop the server.")
    print("=" * 70)
    
    port = int(os.environ.get("PORT", 8000))
    host = os.environ.get("HOST", "0.0.0.0")
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
        
    try:
        import campus_compass.app.main
        app_target = "campus_compass.app.main:app"
    except ImportError:
        app_target = "app.main:app"

    uvicorn.run(app_target, host=host, port=port, reload=False)
